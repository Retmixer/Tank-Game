/* Steel Frontier. Original procedural art; Three.js r160, no external assets. */
(() => {
'use strict';
const D=GameData, $=id=>document.getElementById(id), V=THREE.Vector3;
let save=D.clean(Platform.load()), state='garage', paused=false, scene, world, camera, renderer, preview;
// Temporary economy preset requested for balancing and progression tests.
save.silver=Math.max(99999,save.silver);save.xp=Math.max(99999,save.xp);
let tanks=[],player,bullets=[],particles=[],obstacles=[],solidMeshes=[],ground,arena,rand,trackMarks=[];
let battleTime=0,elapsed=0,capture=0,record,viewYaw=0,viewPitch=0,mouseDown=false,aiming=false,drag=false,dragX=0,lastTime=0,uiTick=0,shake=0,toastTimer,hitTimer;
let matchMode='solo',net=null,netTick=0,countdown=0,countdownClock=null,armorView=false,aimHit=null,garageSection='hangar',researchNation=0,selectedModule='gun';
let engineAudio,engineGain,audio,master,navGrid,navN,navStep=8,lastAimPoint=new V();
const keys={}, ray=new THREE.Raycaster(), up=new V(0,1,0), tmp=new V(), roman=['I','II','III','IV','V'];
const markers=new Map(), wheelGeo=new THREE.CylinderGeometry(.48,.48,.32,12), boxGeo=new THREE.BoxGeometry(1,1,1), sphereGeo=new THREE.IcosahedronGeometry(1,1);
const materials=new Map();
const mat=(color,metalness=.08,roughness=.83)=>{const key=color+':'+metalness+':'+roughness;if(!materials.has(key))materials.set(key,new THREE.MeshStandardMaterial({color,metalness,roughness}));return materials.get(key);};
const trackGeo=new THREE.PlaneGeometry(.52,1.5),holeGeo=new THREE.CircleGeometry(1,12),trackMat=new THREE.MeshBasicMaterial({color:0x20231f,transparent:true,opacity:.28,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-2});
function proceduralTexture(kind){const canvas=document.createElement('canvas');canvas.width=canvas.height=256;const c=canvas.getContext('2d'),winter=kind==='winter',desert=kind==='desert';c.fillStyle=winter?'#c7d2d1':desert?'#b9a174':'#718060';c.fillRect(0,0,256,256);let r=D.rng(winter?71:desert?43:29);for(let i=0;i<900;i++){const v=Math.floor(70+r()*80),a=.025+r()*.08;c.fillStyle=winter?`rgba(${v},${v+8},${v+12},${a})`:desert?`rgba(${v+55},${v+40},${v+16},${a})`:`rgba(${v-25},${v},${v-16},${a})`;c.fillRect(r()*256,r()*256,1+r()*5,1+r()*5);}c.strokeStyle=winter?'#aebfc455':desert?'#8f774530':'#4c5d4038';c.lineWidth=2;for(let i=0;i<18;i++){c.beginPath();c.moveTo(0,r()*256);c.bezierCurveTo(70,r()*256,180,r()*256,256,r()*256);c.stroke();}const tex=new THREE.CanvasTexture(canvas);tex.wrapS=tex.wrapT=THREE.RepeatWrapping;tex.repeat.set(arena.size/24,arena.size/24);tex.colorSpace=THREE.SRGBColorSpace;return tex;}
function mesh(g,m,parent,x=0,y=0,z=0){const o=new THREE.Mesh(g,m);o.position.set(x,y,z);o.castShadow=true;o.receiveShadow=true;parent.add(o);return o;}
function box(parent,w,h,d,x,y,z,color){const o=mesh(boxGeo,mat(color),parent,x,y,z);o.scale.set(w,h,d);return o;}
function cyl(parent,r1,r2,h,x,y,z,color,sides=12){return mesh(new THREE.CylinderGeometry(r1,r2,h,sides),mat(color),parent,x,y,z);}
function angle(a){return Math.atan2(Math.sin(a),Math.cos(a));}
function approach(a,b,step){return a+Math.max(-step,Math.min(step,angle(b-a)));}
function chosen(){return D.tanks.find(t=>t.id===save.selected);}
function mergeMeshes(parent,exclude=[],recursive=false){
 parent.updateMatrixWorld(true);const groups=new Map(),list=[];if(recursive)parent.traverse(o=>{if(o.isMesh)list.push(o);});else list.push(...parent.children.filter(o=>o.isMesh));
 const inverse=parent.matrixWorld.clone().invert();for(const o of list){if(exclude.includes(o)||o.material.vertexColors||Array.isArray(o.material))continue;const key=o.material.uuid+':'+o.castShadow;let entry=groups.get(key);if(!entry){entry={material:o.material,cast:o.castShadow,objects:[],positions:[],normals:[]};groups.set(key,entry);}const g=o.geometry.index?o.geometry.toNonIndexed():o.geometry.clone();g.applyMatrix4(new THREE.Matrix4().multiplyMatrices(inverse,o.matrixWorld));entry.positions.push(g.attributes.position.array);entry.normals.push(g.attributes.normal.array);entry.objects.push(o);g.dispose();}
 for(const entry of groups.values()){if(entry.objects.length<2)continue;const length=entry.positions.reduce((n,a)=>n+a.length,0),p=new Float32Array(length),n=new Float32Array(length);let offset=0;for(let i=0;i<entry.positions.length;i++){p.set(entry.positions[i],offset);n.set(entry.normals[i],offset);offset+=entry.positions[i].length;}const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(p,3));g.setAttribute('normal',new THREE.BufferAttribute(n,3));const merged=mesh(g,entry.material,parent);merged.castShadow=entry.cast;for(const o of entry.objects)o.parent.remove(o);}
}
function persist(){Platform.save(save);$('saveStatus').textContent=Platform.status;}
function toast(text){$('toast').textContent=text;$('toast').style.opacity=1;clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('toast').style.opacity=0,3000);}
function initAudio(){if(audio){audio.resume();return;}try{audio=new (window.AudioContext||window.webkitAudioContext)();master=audio.createGain();master.gain.value=save.settings.volume;master.connect(audio.destination);engineAudio=audio.createOscillator();engineAudio.type='sawtooth';engineGain=audio.createGain();const filter=audio.createBiquadFilter();filter.type='lowpass';filter.frequency.value=170;engineGain.gain.value=0;engineAudio.connect(filter);filter.connect(engineGain);engineGain.connect(master);engineAudio.start();}catch{}}
function sound(type,volume=1){if(!audio||audio.state!=='running')return;const t=audio.currentTime;const gain=audio.createGain();gain.connect(master);const duration=type==='shot'?.35:type==='boom'?.65:.14;gain.gain.setValueAtTime((type==='boom'?.4:type==='shot'?.25:.12)*volume,t);gain.gain.exponentialRampToValueAtTime(.001,t+duration);if(type==='shot'||type==='boom'){const buffer=audio.createBuffer(1,audio.sampleRate*duration,audio.sampleRate);const data=buffer.getChannelData(0);for(let i=0;i<data.length;i++)data[i]=(Math.random()*2-1);const node=audio.createBufferSource();node.buffer=buffer;const filter=audio.createBiquadFilter();filter.type='lowpass';filter.frequency.setValueAtTime(type==='shot'?1800:650,t);filter.frequency.exponentialRampToValueAtTime(80,t+duration);node.connect(filter);filter.connect(gain);node.start();node.stop(t+duration);}else{const o=audio.createOscillator();o.type='sine';o.frequency.setValueAtTime(type==='hit'?420:750,t);o.frequency.exponentialRampToValueAtTime(160,t+duration);o.connect(gain);o.start();o.stop(t+duration);}}

function buildTank(spec,team=0){return Remaster.tank(spec,team);}
function setupScene(kind){
 if(scene){scene.traverse(o=>{if(o.geometry&&o.geometry!==boxGeo&&o.geometry!==wheelGeo&&o.geometry!==sphereGeo&&o.geometry!==holeGeo&&o.geometry!==trackGeo)o.geometry.dispose();});}
 scene=new THREE.Scene();Remaster.lighting(scene);world=new THREE.Group();scene.add(world);obstacles=[];solidMeshes=[];particles=[];bullets=[];trackMarks=[];
 scene.background=new THREE.Color(kind==='garage'?0x8ca39f:D.maps[kind].sky);scene.fog=new THREE.FogExp2(kind==='garage'?0x8ca39f:D.maps[kind].fog,kind==='garage'?.004:.0013);
 const hemi=new THREE.HemisphereLight(kind==='garage'?0xe8f5ef:0xe2eeff,kind==='garage'?0x59645f:0x655c43,kind==='garage'?2.35:1.65);scene.add(hemi);
 const sun=new THREE.DirectionalLight(kind==='garage'?0xfff0c7:0xffecc9,kind==='garage'?4.6:2.05);sun.position.set(-35,65,40);sun.castShadow=true;sun.shadow.mapSize.set(4096,4096);sun.shadow.camera.left=-90;sun.shadow.camera.right=90;sun.shadow.camera.top=90;sun.shadow.camera.bottom=-90;sun.shadow.camera.far=400;sun.shadow.bias=-.0006;sun.shadow.normalBias=.08;scene.add(sun);scene.userData.sun=sun;scene.add(sun.target);if(kind!=='garage')Remaster.sky(scene,kind);const rim=new THREE.DirectionalLight(0xb0d6ff,.65);rim.position.set(40,18,-30);scene.add(rim);
}
function buildHangarSet(){
 const steel=0x293632,trim=0x788076,gold=0xb89a50;
 scene.background=new THREE.Color(0x222a25);scene.fog=new THREE.FogExp2(0x222a25,.012);
 const sun=scene.userData.sun;sun.intensity=3.3;sun.position.set(-12,18,10);sun.shadow.camera.left=-24;sun.shadow.camera.right=24;sun.shadow.camera.top=24;sun.shadow.camera.bottom=-24;sun.shadow.camera.updateProjectionMatrix();
 const set=new THREE.Group();world.add(set);
 const canvas=document.createElement('canvas');canvas.width=canvas.height=512;const ctx=canvas.getContext('2d'),random=D.rng(241);
 ctx.fillStyle='#77786b';ctx.fillRect(0,0,512,512);for(let i=0;i<14000;i++){ctx.fillStyle=random()>.5?'rgba(25,29,23,.12)':'rgba(215,209,181,.09)';ctx.fillRect(random()*512,random()*512,1+random()*3,1+random()*3);}ctx.strokeStyle='#464c43';ctx.lineWidth=3;ctx.strokeRect(2,2,508,508);
 const texture=new THREE.CanvasTexture(canvas);texture.wrapS=texture.wrapT=THREE.RepeatWrapping;texture.repeat.set(14,14);texture.colorSpace=THREE.SRGBColorSpace;
 const floor=mesh(new THREE.BoxGeometry(70,.3,70),new THREE.MeshStandardMaterial({map:texture,roughness:.66,metalness:.13}),world,0,-.25,0);
 // Repair lanes lead into the workshop instead of a circular showroom plinth.
 for(const x of [-5.6,5.6]){box(set,.09,.015,36,x,-.085,-5,gold);box(set,.65,.025,22,x-.4,-.08,-3,0x171d19);for(let z=-14;z<8;z+=.32)box(set,.61,.04,.075,x-.4,-.065,z,trim);}
 box(set,42,12,.5,0,5.9,-19,0x3b453c);box(set,.5,12,48,-21,5.9,0,steel);box(set,.5,12,48,21,5.9,0,steel);
 const glow=new THREE.MeshStandardMaterial({color:0xffe3a1,emissive:0xffdf94,emissiveIntensity:2});
 for(const x of [-18,-12,-6,0,6,12,18]){
  box(set,.45,12,.55,x,5.9,-12,steel);box(set,.8,.25,.85,x,.15,-12,0x1d2621);
  for(let y=.6;y<3;y+=.65){const stripe=box(set,.47,.27,.025,x,y,-11.71,gold);stripe.rotation.z=-.45;}
  box(set,5.7,4,.12,x,5.5,-18.7,0x28332e);box(set,4.7,1.3,.1,x,9.5,-18.65,0x829285);
  box(set,4.7,.08,.13,x,9.5,-18.55,steel);box(set,.08,1.3,.13,x,9.5,-18.5,steel);
  mesh(new THREE.BoxGeometry(2.2,.12,.15),glow,world,x,7.2,-11.7);
 }
 for(const z of [-12,-3,6]){box(set,42,.45,.4,0,11.4,z,steel);box(set,42,.1,.12,0,10.7,z,trim);for(let x=-18;x<19;x+=6){const beam=box(set,.12,.12,6.3,x,11,z,trim);beam.rotation.x=.14;}}
 // Rear workshop bays: pipes, parts shelves and overhead travelling crane.
 for(const y of [3.4,3.65]){const pipe=cyl(set,.045,.045,39,0,y,-18.3,0x6d7157,8);pipe.rotation.z=Math.PI/2;}
 for(const x of [-15,10]){for(const dx of [-1.8,1.8])box(set,.12,4,.5,x+dx,1.9,-17,steel);for(const y of [.5,1.7,2.9]){box(set,3.8,.12,1.2,x,y,-17,trim);for(let j=0;j<3;j++){const part=cyl(set,.36,.36,.24,x-1.1+j*1.1,y+.42,-16.8,0x353d32,16);part.rotation.x=Math.PI/2;}}}
 box(set,38,.48,.4,0,9.7,-7,0x74643c);box(set,2.2,.5,1.2,-8,9.3,-7,steel);cyl(set,.022,.022,3.6,-8,7.3,-7,0x333930,8);
 const hook=mesh(new THREE.TorusGeometry(.22,.055,6,14,Math.PI*1.5),mat(trim),set,-8,5.45,-7);hook.rotation.z=.5;
 function crate(x,z,w=1.6){box(set,w,1.2,w,x,.55,z,0x4a5036);for(const dx of [-w*.36,w*.36]){box(set,.12,1.25,w+.02,x+dx,.56,z,0x77765a);}box(set,w+.06,.1,w+.06,x,1.18,z,0x65674c);}
 for(const [x,z] of [[-8,-7],[-10,-8],[8,-11],[10,-12],[11,-10],[-9,4],[8,5]])crate(x,z);
 for(const x of [-14,-4,7,15]){box(set,1.8,1.6,.8,x,.72,-15,0x873e2c);box(set,1.9,.12,.9,x,1.55,-15,trim);for(let y=.25;y<1.45;y+=.3){box(set,1.6,.015,.04,x,y,-14.58,0x302c22);box(set,.65,.035,.06,x,y+.12,-14.54,0xacaa8a);}}
 box(set,5,.16,1.4,-9,1.7,-16,trim);for(const x of [-11,-7])box(set,.14,1.7,1.2,x,.8,-16,steel);
 for(const x of [12,13.2,14.4]){cyl(set,.44,.44,1.35,x,.6,-8,0x454f3b,16);for(const y of [.2,1])cyl(set,.46,.46,.07,x,y,-8,steel,16);}
 const sign=document.createElement('canvas');sign.width=384;sign.height=512;const c=sign.getContext('2d');c.fillStyle='#999b7f';c.fillRect(0,0,384,512);c.fillStyle='#394334';c.textAlign='center';c.font='bold 43px sans-serif';['ТЕХНИКА','ДЕЛАЕТ','ГРАНИЦЫ','ПРОЧНЕЕ'].forEach((line,i)=>c.fillText(line,192,155+i*57));c.font='82px sans-serif';c.fillText('◇',192,80);c.font='16px sans-serif';c.fillText('СТАЛЬНОЙ РУБЕЖ',192,449);
 const signTexture=new THREE.CanvasTexture(sign);signTexture.colorSpace=THREE.SRGBColorSpace;mesh(new THREE.PlaneGeometry(3.7,5),new THREE.MeshStandardMaterial({map:signTexture,roughness:1}),world,-3.1,5.15,-12.15);
 const hose=new THREE.CatmullRomCurve3([new V(-8,-.04,5),new V(-4,-.04,4),new V(-3,-.04,2.9),new V(-6,-.04,2),new V(-7,-.04,-5)]);mesh(new THREE.TubeGeometry(hose,50,.055,6,false),mat(0x262c25),world);
 // Merge repeated static details while retaining UVs on the concrete and banner.
 mergeMeshes(set,[],true);
 const fill=new THREE.PointLight(0xffd48a,95,26,2);fill.position.set(-3,7,3);scene.add(fill);
}
function hangar(){
 state='garage';paused=false;aiming=false;viewPitch=0;viewYaw=0;countdown=0;countdownClock=null;aimHit=null;garageSection='hangar';Platform.gameplay(false);$('hud').hidden=true;$('hud').classList?.remove?.('aiming');$('garage').hidden=false;$('modal').hidden=true;$('scoreboard').hidden=true;$('researchView').hidden=true;$('garage').classList?.remove?.('research-open');$('hangarTab').classList?.add?.('active');$('researchTab').classList?.remove?.('active');document.exitPointerLock?.();markers.clear();$('markers').innerHTML='';setupScene('garage');
 buildHangarSet();
 preview=buildTank(D.stats(chosen(),save.modules[save.selected]));world.add(preview.group);preview.group.rotation.y=-.70;
 // Reset the battle lens after an aimed shot. Otherwise the garage inherits the
 // low FOV and close camera distance from the previous match.
 camera.fov=45;camera.zoom=1;camera.near=.15;camera.far=2400;camera.updateProjectionMatrix();
 camera.position.set(9.8,6.1,14.8);camera.lookAt(0,1.55,0);renderGarage();Remaster.armorMask(preview,armorView,D.stats(chosen(),save.modules[save.selected]));
 if(engineGain)engineGain.gain.value=0;
}
const tankThumbnails=new Map();
function buildTankThumbnails(){
 if(tankThumbnails.size||!THREE.WebGLRenderer)return;
 const canvas=document.createElement('canvas'),thumbRenderer=new THREE.WebGLRenderer({canvas,alpha:true,antialias:true,preserveDrawingBuffer:true,powerPreference:'high-performance'}),thumbScene=new THREE.Scene(),thumbCamera=new THREE.PerspectiveCamera(34,2.15,.1,80);
 thumbRenderer.setSize(344,160,false);thumbRenderer.setPixelRatio(1);thumbRenderer.outputColorSpace=THREE.SRGBColorSpace;thumbRenderer.toneMapping=THREE.ACESFilmicToneMapping;thumbRenderer.toneMappingExposure=1.12;thumbRenderer.setClearColor?.(0x000000,0);
 thumbScene.add(new THREE.HemisphereLight(0xf2f3df,0x263039,2.35));const key=new THREE.DirectionalLight(0xffe3b5,4.8);key.position.set(-7,11,9);thumbScene.add(key);const rim=new THREE.DirectionalLight(0x84b9d5,2);rim.position.set(8,5,-6);thumbScene.add(rim);
 for(const tank of D.tanks){const model=buildTank(D.stats(tank,save.modules[tank.id]));model.group.rotation.y=-.58;thumbScene.add(model.group);const distance=Math.max(8.2,model.length*1.48);thumbCamera.position.set(distance*.7,3.8,distance);thumbCamera.lookAt(0,1.05,0);thumbRenderer.render(thumbScene,thumbCamera);const image=canvas.toDataURL?.('image/webp',.88);if(image)tankThumbnails.set(tank.id,image);thumbScene.remove(model.group);}
 thumbRenderer.dispose?.();
}
function tankThumbnail(tank){buildTankThumbnails();const src=tankThumbnails.get(tank.id);return src?`<img class="tank-render" src="${src}" alt="3D-модель ${tank.name}">`:'';}
function renderGarage(){
 buildTankThumbnails();
 const owned=!!save.owned[save.selected];
 const armorSpec=D.stats(chosen(),save.modules[save.selected]),zoneNames=['Лоб корпуса','Нижний лоб','Борта','Корма','Лоб башни','Борта башни','Корма башни','Крыша','Гусеницы'];
 $('armorLegend').hidden=!armorView;
 $('armorLegend').innerHTML=D.armorZones.map((z,i)=>{const mm=D.armorThickness(armorSpec,z);return '<span style="color:'+D.armorColor(mm)+'">■ '+zoneNames[i]+': '+mm+' мм</span>';}).join('')+'<small>Цвет — толщина брони: зелёный — тонкая, красный — толстая. Угол и орудие влияют на пробитие.</small>';
 if(armorView)Remaster.armorMask(preview,true,armorSpec);
 const t=chosen(),s=D.stats(t,save.modules[t.id]);$('silver').textContent=save.silver.toLocaleString('ru');$('xp').textContent=save.xp.toLocaleString('ru');$('career').textContent=`${save.battles} боёв · ${save.wins} побед`;$('saveStatus').textContent=Platform.status;
 $('nations').innerHTML=D.nations.map((n,i)=>`<button class="${i===t.n?'active':''}" data-nation="${i}">${n}</button>`).join('');$('nations').querySelectorAll('button').forEach(b=>b.onclick=()=>selectNation(+b.dataset.nation));
 $('tankClass').textContent=`${t.cls.toUpperCase()} / ${roman[s.level-1]}`;$('tankName').textContent=t.name;$('tankDesc').textContent=t.description;$('nationLabel').textContent=t.nation.toUpperCase();
 const entries=[['♨','Огневая мощь',s.damage+' ед.',s.damage/300],['◈','Прочность',s.hp+' HP',s.hp/1600],['◴','Скорость',Math.round(s.speed*3.6)+' км/ч',s.speed/20],['▰','Масса',s.mass+' т',s.mass/70],['▣','Двигатель',s.power+' л.с.',s.power/800]];
 $('stats').innerHTML=entries.map(([icon,name,value,ratio])=>`<div class="stat"><span class="stat-icon">${icon}</span><div><div><span>${name}</span><b>${value}</b></div><div class="stat-track"><i style="width:${Math.min(100,ratio*100)}%"></i></div></div></div>`).join('');
 $('level').textContent=roman[s.level-1];$('levelBadge').textContent=roman[s.level-1];$('vehicleCode').textContent='P-'+t.name.match(/\d+/)?.[0];$('levelBars').innerHTML=roman.map((_,i)=>`<i class="${i<s.level?'on':''}"></i>`).join('');
 $('blueprintImage').src=tankThumbnails.get(t.id)||'';$('tankLength').textContent=preview.length.toFixed(2).replace('.',',')+' м';$('tankWidth').textContent=preview.width.toFixed(2).replace('.',',')+' м';$('tankHeight').textContent=(2.05+t.c*.24).toFixed(2).replace('.',',')+' м';$('tankMass').textContent=s.mass+' т';
 const nationTanks=(save.purchaseOrder||Object.keys(save.owned)).filter(id=>save.owned[id]).map(id=>D.tanks.find(v=>v.id===id)).filter(Boolean);$('tankCards').innerHTML=nationTanks.map(v=>`<button class="tank-card ${v.id===t.id?'selected':''} ${save.owned[v.id]?'':'locked'}" data-tank="${v.id}" aria-label="Выбрать танк ${v.name}"><small>${roman[save.levels[v.id]-1]} · ${v.cls.toUpperCase()}</small><span class="card-num">0${v.c+1}</span><strong>${v.name}</strong><em>${save.owned[v.id]?(v.id===t.id?'ВЫБРАН':'ГОТОВ К БОЮ'):'НЕ ИССЛЕДОВАН'}</em>${tankThumbnail(v)}</button>`).join('');$('tankCards').querySelectorAll('button').forEach(b=>b.onclick=()=>{if(save.owned[b.dataset.tank])selectTank(b.dataset.tank);else{researchNation=t.n;showGarageSection('research');}});$('mapSelect').value=save.map;updateMapCard();renderResearch();
 renderModule(s);$('battleBtn').disabled=!owned;$('unlockPanel').hidden=owned;const price=D.price(save.selected);$('unlockInfo').textContent=`Исследование ${price.xp} опыта · покупка ${price.silver} серебра`;$('unlockBtn').disabled=save.xp<price.xp||save.silver<price.silver;$('upgradeBtn').disabled=$('upgradeBtn').disabled||!owned;$('armorBtn').textContent=armorView?'МАСКА БРОНИ: ВКЛ':'МАСКА БРОНИ: ВЫКЛ';
}
function renderModule(s){
 const key=selectedModule,level=s.modules[key],next=D.stats(chosen(),{...s.modules,[key]:Math.min(5,level+1)}),max=level===5;
 for(const k of Object.keys(D.moduleNames)){const b=$('module-'+k);b.classList?.toggle?.('active',k===key);b.setAttribute?.('aria-pressed',String(k===key));$('module-level-'+k).textContent='УР. '+roman[s.modules[k]-1];}
 const pen=x=>Math.round(D.penetration(x,x,'front',1,0).power),front=x=>D.armorThickness(x,'front');
 const rows={gun:[['Средний урон',s.damage,next.damage,' ед.'],['Пробитие',pen(s),pen(next),' мм'],['Перезарядка',s.reload,next.reload,' с']],armor:[['Прочность',s.hp,next.hp,' HP'],['Лоб корпуса',front(s),front(next),' мм'],['Лоб башни',D.armorThickness(s,'turret'),D.armorThickness(next,'turret'),' мм']],engine:[['Мощность',s.power,next.power,' л.с.'],['Удельная мощность',+(s.power/s.mass).toFixed(1),+(next.power/s.mass).toFixed(1),' л.с./т'],['Макс. скорость',Math.round(s.speed*3.6),Math.round(next.speed*3.6),' км/ч']],tracks:[['Прочность ходовой',s.tracks,next.tracks,' ед.'],['Поворот корпуса',Math.round(s.turn*180/Math.PI),Math.round(next.turn*180/Math.PI),' °/с'],['Масса машины',s.mass,next.mass,' т']]}[key];
 $('moduleName').textContent=key==='gun'?`ОРУДИЕ ${[57,76,105,152][s.c]+s.n*3} ММ`:D.moduleNames[key].toUpperCase();$('level').textContent=roman[level-1];
 $('moduleStats').innerHTML=rows.map(([label,value,future,unit])=>`<dt>${label}</dt><dd>${String(value).replace('.',',')}${unit}${!max&&future!==value?` <em>→ ${String(future).replace('.',',')}${unit}</em>`:''}</dd>`).join('');
 $('levelBars').innerHTML=roman.map((r,i)=>`<i class="${i<level?'on':''}" title="Уровень ${r}"></i>`).join('');
 $('upgradeInfo').textContent=max?'Модуль полностью улучшен. Выберите другой модуль.':{gun:'Урон, пробитие и точность. Быстрее перезарядка и сведение.',armor:'Усиливает индивидуальные зоны брони и запас прочности.',engine:'Больше тяги: быстрее разгон и подъём. Предел скорости сохранён.',tracks:'Прочнее ходовая и быстрее поворот корпуса.'}[key];
 $('upgradeBtn').textContent=max?'МОДУЛЬ УЛУЧШЕН ДО V':`⌃  УЛУЧШИТЬ     ${D.costs[level].toLocaleString('ru')} ◉`;$('upgradeBtn').disabled=max||save.silver<D.costs[level];
}
function selectTank(id){if(!save.owned[id])return;save.selected=id;save.nation=chosen().n;persist();world.remove(preview.group);preview=buildTank(D.stats(chosen(),save.modules[id]));preview.group.rotation.y=-.70;world.add(preview.group);Remaster.armorMask(preview,armorView,D.stats(chosen(),save.modules[save.selected]));sound('ui');renderGarage();}
function selectNation(n){const next=D.tanks.find(v=>v.n===n&&save.owned[v.id]);if(next)selectTank(next.id);else{researchNation=n;showGarageSection('research');}}
function updateMapCard(){const m=D.maps[save.map];$('mapPreview').innerHTML=`<span>0${Object.keys(D.maps).indexOf(save.map)+1}</span><div>${m.name.toUpperCase()}<small>${m.subtitle}</small></div>`;$('mapPreview').style.backgroundColor=save.map==='desert'?'#796341':save.map==='winter'?'#506a77':'#334333';updateModeCard();}
function updateModeCard(){const lan=$('modeSelect').value==='lan';$('modeName').textContent=lan?'◈ ЛОКАЛЬНАЯ СЕТЬ':'◈ КОМАНДНЫЙ БОЙ';$('modeSize').textContent=lan?'1 × 1':'3 × 3';$('modeDescription').textContent=lan?'Создайте лобби или войдите по коду через Radmin VPN.':'Уничтожьте противника или удержите центральную базу.';$('modeNote').textContent=lan?'НУЖЕН ЗАПУСК ЧЕРЕЗ PLAY.CMD НА КОМПЬЮТЕРЕ-ХОСТЕ':'ОДИНОЧНАЯ ИГРА • СОЮЗНИКИ И ВРАГИ — БОТЫ';$('battleBtn').innerHTML=lan?'ЛОББИ <span>→</span>':'В БОЙ <span>→</span>';}
function showGarageSection(section){garageSection=section;$('garage').classList?.toggle?.('research-open',section==='research');$('researchView').hidden=section!=='research';$('hangarTab').classList?.toggle?.('active',section==='hangar');$('researchTab').classList?.toggle?.('active',section==='research');if(section==='research')renderResearch();}
function renderResearch(){if(!$('researchTree'))return;$('researchNations').innerHTML=D.nations.map((name,n)=>`<button class="${n===researchNation?'active':''}" data-research-nation="${n}">${name}</button>`).join('');$('researchNations').querySelectorAll('button').forEach(b=>b.onclick=()=>{researchNation=+b.dataset.researchNation;renderResearch();});$('researchTree').innerHTML=D.tanks.filter(t=>t.n===researchNation).map((t,index)=>{const owned=!!save.owned[t.id],price=D.price(t.id),level=save.levels[t.id];return `<article data-class="${t.c}" class="research-node ${owned?'owned':'locked'} ${t.id===save.selected?'selected':''}"><div class="research-tier">${t.c===3?'ВЕТКА ПОДДЕРЖКИ':'ОСНОВНАЯ ВЕТКА'} · 0${index+1} · ${t.cls.toUpperCase()}</div><div class="research-silhouette nation-${t.n} class-${t.c}">${tankThumbnail(t)}</div><h3>${t.name}</h3><p>${t.description}</p><div class="research-spec"><span>БРОНЯ <b>${t.armor}%</b></span><span>УРОН <b>${t.damage}</b></span><span>СКОРОСТЬ <b>${Math.round(t.speed*3.6)}</b></span></div>${owned?`<button class="research-action owned-action" data-research-select="${t.id}">${t.id===save.selected?'ВЫБРАН':'ВЫБРАТЬ'} · ${roman[level-1]} УР.</button>`:`<div class="research-price"><b>${price.xp} ✦</b><b>${price.silver} ◉</b></div><button class="research-action" data-research-unlock="${t.id}" ${save.xp<price.xp||save.silver<price.silver?'disabled':''}>ИССЛЕДОВАТЬ И КУПИТЬ</button>`}</article>`;}).join('');$('researchTree').querySelectorAll('[data-research-select]').forEach(b=>b.onclick=()=>{selectTank(b.dataset.researchSelect);showGarageSection('hangar');});$('researchTree').querySelectorAll('[data-research-unlock]').forEach(b=>b.onclick=()=>{const id=b.dataset.researchUnlock;if(D.unlock(save,id)){persist();renderGarage();renderResearch();toast('Танк исследован и добавлен в ангар');}});}

// Общая высота ландшафта. Центр оставляем проходимым для базы, а за его пределами
// смешиваем крупные холмы, поперечные гряды и мелкую неровность поверхности.
function terrainHeightRaw(x,z){
 if(!arena)return 0;
 const edge=Math.min(1,Math.max(0,(Math.max(Math.abs(x),Math.abs(z))-22)/42));
 const center=Math.max(.35,edge);
 const broad=Math.sin(x*.018+Math.sin(z*.011)*.8)*Math.cos(z*.015-x*.006);
 const ridges=Math.sin((x+z)*.032+Math.sin(x*.009)*1.5)+.55*Math.cos((x-z)*.047);
 const detail=Math.sin(x*.11+z*.07)*Math.cos(z*.095-x*.04);
 let h;
 if(arena===D.maps.desert){
  const dunes=Math.sin(x*.031+z*.012)+.55*Math.sin(z*.052-x*.018);
  h=(broad*5.2+ridges*3.4+dunes*2.4+detail*.7)*center;
 }else if(arena===D.maps.winter){
  const snowRidges=Math.sin(z*.026+x*.014)*Math.cos(x*.021)+.5*Math.sin((x-z)*.041);
  h=(broad*4.8+snowRidges*3.8+detail*.55)*center;
 }else{
  h=(broad*5.5+ridges*3.8+detail*.8)*center;
 }
 // Лёгкие впадины вокруг центрального поля дают естественный силуэт, но не мешают старту.
 const basin=Math.max(0,1-Math.hypot(x,z)/85);
 const playable=arena.size*.5,edgeStart=arena.size*.415,edgeT=Math.max(0,Math.min(1,(Math.max(Math.abs(x),Math.abs(z))-edgeStart)/(playable-edgeStart)));
 const escarpment=edgeT*edgeT*(3-2*edgeT)*(arena===D.maps.desert?24:32);
 return h*(1-basin*.38)+escarpment;
}
// Physics and props use exactly the same triangles as the visible ground.
function height(x,z){
 if(!arena)return 0;
 const n=save.settings.quality==='high'?220:128,step=arena.size/n,half=arena.size/2;
 if(Math.abs(x)>half||Math.abs(z)>half)return terrainHeightSmooth(x,z);
 const ix=Math.min(n-1,Math.max(0,Math.floor((x+half)/step))),iz=Math.min(n-1,Math.max(0,Math.floor((z+half)/step)));
 const ax=ix*step-half,az=iz*step-half,u=(x-ax)/step,v=(z-az)/step;
 const a=terrainHeightSmooth(ax,az),b=terrainHeightSmooth(ax,az+step),d=terrainHeightSmooth(ax+step,az);
 return u+v<=1?a+(d-a)*u+(b-a)*v:b*(1-u)+d*(1-v)+terrainHeightSmooth(ax+step,az+step)*(u+v-1);
}
function terrainHeightSmooth(x,z){
 if(!arena)return 0;
 let h=terrainHeightRaw(x,z);const spawnZ=arena.size*.4;
 // Broad, gently blended deployment terraces keep every vehicle clear of the
 // perimeter mountains and give a full team room to turn before climbing.
 for(const side of [-1,1]){
  const dz=Math.abs(z-side*spawnZ),xFade=Math.max(0,Math.min(1,(74-Math.abs(x-side*spawnZ))/30)),zFade=Math.max(0,Math.min(1,(72-dz)/46));
  const blend=xFade*xFade*(3-2*xFade)*zFade*zFade*(3-2*zFade),plateau=terrainHeightRaw(side*spawnZ,side*spawnZ);
  h=h*(1-blend)+plateau*blend;
 }
 // Flatten the factory floor and soften the three connected battle lanes.
 const laneX=arena.size*.29;
 const laneDistance=Math.min(Math.abs(x),Math.abs(x-laneX),Math.abs(x+laneX),Math.abs(z));
 const laneBlend=1-THREE.MathUtils.smoothstep(laneDistance,10,30);
 const interior=1-THREE.MathUtils.smoothstep(Math.abs(z),arena.size*.32,arena.size*.43);
 h*=1-laneBlend*interior*.82;
 if(arena===D.maps.winter)h*=1-(1-THREE.MathUtils.smoothstep(Math.max(Math.abs(x),Math.abs(z)),arena.size*.26,arena.size*.4))*.92;
 return h;
}
function obstacle(obj,x,z,r){obj.updateMatrixWorld(true);const bounds=new THREE.Box3().setFromObject(obj);obstacles.push({x,z,r,object:obj,bounds});obj.traverse(o=>{if(o.isMesh)solidMeshes.push(o);});}
function footprintSupport(x,z,w,d){const samples=[];for(const sx of [-.5,0,.5])for(const sz of [-.5,0,.5])samples.push(height(x+sx*w,z+sz*d));return {low:Math.min(...samples),high:Math.max(...samples)};}
function building(x,z,w,d,h,industrial=false){const support=footprintSupport(x,z,w,d),foundation=Math.max(.8,support.high-support.low+.55),g=new THREE.Group();g.position.set(x,support.high-.08,z);world.add(g);box(g,w+.75,foundation,d+.75,0,-foundation/2+.12,0,arena===D.maps.desert?0x756b59:0x59625f);box(g,w,h,d,0,h/2,0,industrial?0x6a7779:arena===D.maps.desert?0xc2ae86:0xa0a391);box(g,w+.3,.25,d+.3,0,h,0,0x515c5d);
 if(!industrial){const rw=w/2+.4,rd=d/2+.4;const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute([-rw,0,-rd,rw,0,-rd,0,2.1,-rd,-rw,0,rd,rw,0,rd,0,2.1,rd],3));geo.setIndex([0,2,1,3,4,5,0,3,5,0,5,2,1,2,5,1,5,4,0,1,4,0,4,3]);geo.computeVertexNormals();mesh(geo,mat(arena===D.maps.winter?0xc6d2d2:0x626957),g,0,h,0);}
 for(const side of [-1,1])for(let a=-w/2+1.2;a<w/2-.5;a+=2){box(g,.65,1.1,.09,a,h*.58,side*(d/2+.06),0x34474a);box(g,.8,.13,.17,a,h*.58-.6,side*(d/2+.1),0x7d8984);}
 box(g,1.2,2.3,.13,w*.18,1.15,d/2+.05,0x50584d);Remaster.building(g,w,d,h,industrial,arena===D.maps.desert?'desert':arena===D.maps.winter?'winter':'training');obstacle(g,x,z,Math.hypot(w,d)*.5+.15);
}
function rock(x,z,r){const o=mesh(new THREE.IcosahedronGeometry(r,2),mat(arena===D.maps.desert?0x9d886d:arena===D.maps.winter?0x8a9b9e:0x777e72),world,x,height(x,z)+r*.46,z);o.scale.set(1.2,.8,1);o.rotation.set(rand()*.4,rand()*6,.2);obstacle(o,x,z,r*1.08);}
function tree(x,z){const g=new THREE.Group();g.position.set(x,height(x,z),z);world.add(g);const h=4+rand()*4;cyl(g,.15,.25,h,0,h/2,0,0x535147,6);for(let j=0;j<3;j++)cyl(g,0,2-j*.4,3.6,0,h-1+j*1.2,0,arena===D.maps.winter?0x768e86:0x4a6350,7);}
function buildBackdrop(){const size=arena.size,isWinter=arena===D.maps.winter,isDesert=arena===D.maps.desert,far=size*.7;
 if(!isDesert){for(let side of [-1,1])for(let i=-8;i<=8;i++){const x=i*18+(rand()-.5)*7,z=side*(far+rand()*22);if(isWinter){const h=10+rand()*24;box(world,10+rand()*9,h,9,x,h/2-1,z,0x60727a);if(i%3===0)cyl(world,1.1,1.5,h+15,x+4,(h+15)/2,z,0x718087,10);}else{const g=new THREE.Group();g.position.set(x,-2,z);world.add(g);const h=9+rand()*12;cyl(g,.28,.45,h,0,h/2,0,0x3f463c,6);for(let j=0;j<3;j++)cyl(g,0,3.4-j*.7,5.5,0,h-2+j*1.8,0,0x405c49,7);}}
 }else{for(let side of [-1,1])for(let i=-7;i<=7;i++){const x=i*24+(rand()-.5)*10,z=side*(far+rand()*20),h=5+rand()*14;box(world,9+rand()*13,h,8,x,h/2-2,z,0x8e795b);if(i%4===0)cyl(world,1.2,1.8,h+11,x+5,(h+11)/2-2,z,0x9c8968,10);}}
 if(arena===D.maps.training){for(let i=-5;i<=5;i++){const x=i*22,z=far*.94+(i%2)*8,w=8+rand()*5,h=5+rand()*5;box(world,w,h,7,x,h/2-1,z,0x777867);box(world,w+.4,.5,7.4,x,h,z,0x4e5549);}}
}
function scatterProps(){const isWinter=arena===D.maps.winter,isDesert=arena===D.maps.desert;for(let i=0;i<26;i++){const x=(rand()-.5)*(arena.size-30),z=(rand()-.5)*(arena.size-30);if(Math.abs(x)<15||obstacles.some(o=>Math.hypot(o.x-x,o.z-z)<o.r+3))continue;const g=new THREE.Group();g.position.set(x,height(x,z),z);world.add(g);if(i%3===0){for(let k=0;k<3;k++){const b=cyl(g,.32,.32,.8,(k-1)*.7,.4,0,isDesert?0x756241:0x5c6868,12);b.rotation.z=k===2?Math.PI/2:0;}}else if(i%3===1){box(g,2.2,.85,1.2,0,.43,0,isWinter?0x6b7675:0x746d50);box(g,1.9,.12,1.25,0,.9,0,0x424b44);obstacle(g,x,z,1.4);}else{for(let k=-2;k<=2;k++)box(g,.12,1.4,.12,k*.65,.7,0,0x545a50);box(g,3.1,.12,.12,0,.9,0,0x545a50);}}
}
function naturalBoundary(){
 const edge=arena.size*.468,stone=mat(arena===D.maps.desert?0x92785b:arena===D.maps.winter?0x7f9299:0x68746b),step=26,shared=new THREE.IcosahedronGeometry(1,1);
 const add=(x,z,i,vertical)=>{const r=8+(i%4)*1.8,o=mesh(shared,stone,world,x,height(x,z)+r*.48,z);o.scale.set(vertical?.9:1.45,.8,vertical?1.45:.9);o.rotation.set(.12*(i%3),i*.77,.08*(i%2));obstacle(o,x,z,r*.76);};
 let i=0;for(let a=-edge;a<=edge;a+=step){add(a,-edge,i++,false);add(a,edge,i++,false);}for(let a=-edge+step;a<edge;a+=step){add(-edge,a,i++,true);add(edge,a,i++,true);}
}
// Authored districts use the same deterministic layout for solo and LAN.
function buildDistricts(){
 const size=arena.size,winter=arena===D.maps.winter,desert=arena===D.maps.desert;
 const flank=size*.29,decor=new THREE.Group();world.add(decor);
 const steel=Remaster.material(0x616d70,'steel'),wood=Remaster.material(0x71614a,'wood');
 const concrete=Remaster.material(desert?0xb29570:0x85877c,'rock');
 function cover(x,z,w=7,d=3,h=2){
  const g=new THREE.Group(),support=footprintSupport(x,z,w,d);g.position.set(x,support.low-.1,z);world.add(g);h+=support.high-support.low+.1;
  const b=box(g,w,h,d,0,h/2,0,0x827a60);b.material=concrete;
  for(let a=-w/2+1;a<w/2;a+=2){const seam=box(g,.1,h+.05,d+.05,a,h/2,0,0x494d43);seam.material=steel;}
  obstacle(g,x,z,Math.hypot(w,d)/2+.2);
 }
 function route(points,width,kind){
  const vertices=[],uv=[],indices=[];
  for(let p=0;p<points.length-1;p++){
   const [ax,az]=points[p],[bx,bz]=points[p+1],len=Math.hypot(bx-ax,bz-az),n=Math.ceil(len/2),bands=Math.ceil(width/2),nx=-(bz-az)/len,nz=(bx-ax)/len;
   for(let i=0;i<n;i++)for(let j=0;j<bands;j++){
    const lo=j/bands*2-1,hi=(j+1)/bands*2-1,start=vertices.length/3;
    for(const [t,s] of [[i/n,lo],[i/n,hi],[(i+1)/n,lo],[(i+1)/n,hi]]){const x=ax+(bx-ax)*t+nx*width*s/2,z=az+(bz-az)*t+nz*width*s/2;vertices.push(x,height(x,z)+.16,z);uv.push(x/8,z/8);}
    indices.push(start,start+1,start+2,start+1,start+3,start+2);
   }
  }
  const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));geo.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));geo.setIndex(indices);geo.computeVertexNormals();
  const road=mesh(geo,Remaster.material(kind==='ice'?0x96b5c1:desert?0x9c896e:winter?0x686f72:0xaaa38b,kind==='ice'?'ice':'road'),decor);road.castShadow=false;
 }
 function tower(x,z){const g=new THREE.Group();g.position.set(x,footprintSupport(x,z,5,5).low,z);decor.add(g);for(const a of [-1,1])for(const b of [-1,1]){const leg=box(g,.35,10,.35,a*2,5,b*2,0x55635c);leg.material=steel;}box(g,5,.4,5,0,9,0,0x666b5b);box(g,5,1,.2,0,10,2.4,0x717566);box(g,5,1,.2,0,10,-2.4,0x717566);box(g,5.6,.35,5.6,0,12,0,0x505b55);for(let y=0;y<9;y+=.6){const step=box(g,1,.1,.25,2,y,0,0x666c60);step.material=steel;}}
 function supplies(x,z){const g=new THREE.Group();g.position.set(x,footprintSupport(x+1.3,z,5,1.8).low,z);decor.add(g);for(let j=0;j<4;j++){const c=box(g,2.4,1.5,1.8,(j%2)*2.6,.75+Math.floor(j/2)*1.5,0,0x736c50);c.material=wood;for(const dx of [-.9,.9]){const strap=box(g,.12,1.55,1.85,(j%2)*2.6+dx,.75+Math.floor(j/2)*1.5,0,0x414d47);strap.material=steel;}}obstacle(g,x+1.3,z,2.8);}
 route([[0,-size*.4],[0,0],[0,size*.4]],16,'road');
 for(const s of [-1,1])route([[0,-size*.4],[s*flank,-size*.29],[s*flank,0],[s*flank,size*.29],[0,size*.4]],desert?19:15,'road');
 route([[-flank,0],[0,0],[flank,0]],18,'road');
 if(desert){
  // Broken rock ridges separate the dry riverbed from the central outpost.
  for(const side of [-1,1])for(const z of [-.27,-.17,.17,.27])for(let j=0;j<3;j++)rock(side*(size*.18+j*9),size*z+j*8,8+j*2);
  for(const side of [-1,1])for(const z of [-65,65]){building(side*48,z,18,15,5,false);cover(side*26,z+side*17,10,3,3);supplies(side*63,z-12);}
  for(const side of [-1,1]){building(side*90,side*size*.32,22,16,6);tower(side*115,side*size*.32);for(let j=0;j<4;j++)cover(side*(65+j*18),side*size*.1,7,3,2.6);}
  route([[flank,-size*.3],[flank+24,-size*.15],[flank+12,0],[flank+24,size*.2],[0,size*.4]],23,'road');
 }else if(winter){
  // Four factory quadrants; central and lateral streets remain open.
  for(const sx of [-1,1])for(const sz of [-1,1]){
   for(let j=0;j<3;j++)building(sx*(42+j*33),sz*65,23,54,12+j*2,true);
   building(sx*70,sz*132,45,24,10,true);supplies(sx*35,sz*112);cover(sx*35,sz*25,8,3,2);
   const x=sx*120,z=sz*145,y=height(x,z);for(let j=0;j<2;j++){const chimney=cyl(decor,3.2,4,36,x+j*11,y+18,z,0x737b7b,20);chimney.material=Remaster.material(0x8a8076,'brick');for(let k=0;k<4;k++){const band=cyl(decor,3.5,3.5,1,x+j*11,y+10+k*7,z,0x5a6261,20);band.material=steel;}}
  }
  // Rail siding on the west flank; raised sleepers remain below track clearance.
  for(let z=-size*.34;z<size*.34;z+=3){const x=-flank-20,y=footprintSupport(x,z,5,3).low;const sleeper=box(decor,5,.12,.32,x,y+.1,z,0x665a4b);sleeper.material=wood;for(const dx of [-1.4,1.4]){const rail=box(decor,.14,.16,3.05,x+dx,y+.18,z,0x596369);rail.material=steel;}}
  for(const z of [-140,-110,105,135]){building(-flank-37,z,9,20,4,true);}
  route([[flank+26,-size*.36],[flank+30,0],[flank+26,size*.36]],23,'ice');
 }else{
  for(const side of [-1,1]){
   for(const x of [-105,105]){building(x,side*size*.29,28,42,9,true);supplies(x+22,side*size*.27);tower(x*1.6,side*size*.26);}
   for(const x of [-55,55]){building(x,side*size*.39,22,28,8,true);supplies(x+16,side*size*.37);}
   for(const x of [-70,70])for(const z of [45,95,145]){cover(x,side*z,12,3,2.3);cover(x+Math.sign(x)*9,side*(z+6),3,12,2.3);}
   for(let i=0;i<5;i++){const x=side*(35+i*26);cover(x,side*size*.12,6,3,1.6);supplies(x,side*(size*.12+20));}
   building(side*size*.35,side*45,15,24,7,true);
  }
 }
 // Cover islands at lane junctions break uninterrupted spawn-to-spawn shots.
 for(const s of [-1,1])for(const z of [-size*.22,size*.22]){cover(s*26,z,9,4,2.7);cover(s*(flank-23),z,8,4,2.4);supplies(s*(flank-33),z+12);}
 Remaster.batch(decor,[],true);
}
function buildMap(){
 rand=D.rng(arena.seed);const size=arena.size,segments=save.settings.quality==='high'?220:128;const geo=new THREE.PlaneGeometry(size,size,segments,segments);geo.rotateX(-Math.PI/2);const pos=geo.attributes.position, colors=[];for(let i=0;i<pos.count;i++){const x=pos.getX(i),z=pos.getZ(i);pos.setY(i,height(x,z));const c=new THREE.Color(arena.ground);let tint=.9+rand()*.16;if(Math.abs(x)<5||Math.abs(z)<4)tint*=.87;c.multiplyScalar(tint);colors.push(c.r,c.g,c.b);}geo.setAttribute('color',new THREE.Float32BufferAttribute(colors,3));geo.computeVertexNormals();ground=mesh(geo,Remaster.terrainMaterial(arena===D.maps.winter?'winter':arena===D.maps.desert?'desert':'training',size),world);ground.receiveShadow=true;ground.castShadow=false;
 const isWinter=arena===D.maps.winter;
 buildDistricts();
 for(let i=0;i<(isWinter?22:38);i++){const x=(rand()-.5)*(size-24),z=(rand()-.5)*(size-34);if(Math.abs(x)<15||Math.abs(z)>size*.37||obstacles.some(o=>Math.hypot(o.x-x,o.z-z)<o.r+8))continue;rock(x,z,2+rand()*3.5);}
 for(const [x,z] of [[-17,-13],[18,15],[-55,-50],[54,48]]){const g=new THREE.Group();g.position.set(x,height(x,z),z);world.add(g);box(g,9,1.5,1.4,0,.75,0,isWinter?0x8c9a9b:0x84866f);obstacle(g,x,z,4.8);}
 for(let i=0;i<14;i++){const x=(rand()>.5?1:-1)*(25+rand()*45),z=(rand()-.5)*140;if(obstacles.some(o=>Math.hypot(o.x-x,o.z-z)<o.r+4))continue;const g=new THREE.Group();g.position.set(x,height(x,z),z);world.add(g);box(g,2,1.6,2,0,.8,0,0x716c50);box(g,2.05,.13,2.05,0,1.3,0,0x434b43);obstacle(g,x,z,1.45);}
 if(isWinter){for(const x of [-55,56]){const y=height(x,-65);cyl(world,2,2.8,25,x,y+12.5,-65,0x677b82);for(let j=0;j<3;j++)cyl(world,2.06,2.06,1.1,x,y+15+j*4,-65,0x9b9183);}}
 // Small ruined farmsteads and supply positions connect the larger settlements.
 for(const side of [-1,1])for(const flank of [-1,1])for(let i=0;i<3;i++){
  const x=flank*(80+i*47),z=side*(35+i*39);if(obstacles.some(o=>Math.hypot(o.x-x,o.z-z)<o.r+9))continue;
  const g=new THREE.Group();g.position.set(x,height(x,z),z);world.add(g);
  box(g,8,1.6,.65,0,.8,0,isWinter?0x777d7a:0x8b8068);box(g,.65,2.4,3,-3.7,1.2,-1.2,0x817967);
  for(let k=0;k<5;k++)box(g,.7,.4,.6,-3+k*1.4,.18,1.2+(k%2)*.45,0x8a806b);
  obstacle(g,x,z,4.5);
 }
 scatterProps();buildBackdrop();
 const baseY=height(0,0),ring=mesh(new THREE.RingGeometry(11.7,12,72),new THREE.MeshBasicMaterial({color:0xddcc92,side:THREE.DoubleSide,transparent:true,opacity:.75}),world,0,baseY+.12,0);ring.rotation.x=-Math.PI/2;const pole=cyl(world,.08,.08,6,0,baseY+3,0,0xb4b7a3,8);const flag=box(world,1.8,1,.05,.95,baseY+5.3,0,0xc3b784);pole.castShadow=false;flag.castShadow=false;
 Remaster.environment(world,arena,height,rand,save.settings.quality);naturalBoundary();Remaster.vegetation(world,arena,height,obstacles,save.settings.quality);world.updateMatrixWorld(true);makeNavigation();
}
function blocked(x,z,r=2.1){return Math.abs(x)>arena.size/2-r-1||Math.abs(z)>arena.size/2-r-1||obstacles.some(o=>o.bounds?x+r>o.bounds.min.x&&x-r<o.bounds.max.x&&z+r>o.bounds.min.z&&z-r<o.bounds.max.z:(x-o.x)**2+(z-o.z)**2<(r+o.r)**2);}
function makeNavigation(){navN=Math.floor(arena.size/navStep);navGrid=new Uint8Array(navN*navN);for(let z=0;z<navN;z++)for(let x=0;x<navN;x++)navGrid[z*navN+x]=blocked((x+.5)*navStep-arena.size/2,(z+.5)*navStep-arena.size/2,2.5)?1:0;}
function route(ax,az,bx,bz){const idx=(x,z)=>Math.max(0,Math.min(navN-1,Math.floor((z+arena.size/2)/navStep)))*navN+Math.max(0,Math.min(navN-1,Math.floor((x+arena.size/2)/navStep)));const start=idx(ax,az);let goal=idx(bx,bz);if(navGrid[goal]){let best=Infinity;for(let i=0;i<navGrid.length;i++)if(!navGrid[i]){const d=(i%navN-goal%navN)**2+(Math.floor(i/navN)-Math.floor(goal/navN))**2;if(d<best){best=d;goal=i;}}}const open=[start],cost=new Float32Array(navN*navN).fill(Infinity),prev=new Int32Array(navN*navN).fill(-1),closed=new Uint8Array(navN*navN);cost[start]=0;let loops=0;const heuristic=i=>Math.hypot(i%navN-goal%navN,Math.floor(i/navN)-Math.floor(goal/navN));while(open.length&&loops++<12000){let k=0;for(let i=1;i<open.length;i++)if(cost[open[i]]+heuristic(open[i])<cost[open[k]]+heuristic(open[k]))k=i;const current=open.splice(k,1)[0];if(current===goal){const p=[];let v=goal;while(v!==start&&v!==-1){p.push({x:(v%navN+.5)*navStep-arena.size/2,z:(Math.floor(v/navN)+.5)*navStep-arena.size/2});v=prev[v];}return p.reverse();}closed[current]=1;const x=current%navN,z=Math.floor(current/navN);for(const [dx,dz] of [[1,0],[-1,0],[0,1],[0,-1],[1,1],[-1,1],[1,-1],[-1,-1]]){const nx=x+dx,nz=z+dz;if(nx<0||nz<0||nx>=navN||nz>=navN)continue;const n=nz*navN+nx;if(navGrid[n]||closed[n]||(dx&&dz&&(navGrid[z*navN+nx]||navGrid[nz*navN+x])))continue;const nc=cost[current]+(dx&&dz?1.414:1);if(nc<cost[n]){cost[n]=nc;prev[n]=current;if(!open.includes(n))open.push(n);}}}return [];}
function spawn(spec,team,index,isPlayer=false){const model=buildTank(spec,team);const side=team===0?-1:1,x=side*arena.size*.4+(index-1)*12,z=side*arena.size*.4-(index-1)*12;model.group.position.set(x,height(x,z),z);world.add(model.group);const t={...model,spec,team,isPlayer,hp:spec.hp,yaw:team===0?Math.PI/4:-Math.PI*3/4,turretYaw:team===0?0:Math.PI,reload:1+index*.25,speed:0,alive:true,target:null,think:rand()*.4,path:[],navTime:0,seen:false,aimTime:0,aimBloom:1,revealTime:0,stuck:0,trackTime:0,name:isPlayer?'Вы':(team===0?['Кедр','Сокол','Риф'][index]:['Коршун','Кремень','Буран'][index])};model.group.rotation.y=t.yaw;Remaster.suspension(t,height,1/60);model.hitMeshes.forEach(o=>o.userData.tank=t);if(!isPlayer&&matchMode!=='lan')t.brain=createBrain();tanks.push(t);if(!isPlayer){const el=document.createElement('div');el.className='marker '+(team===0?'friendly':'');$('markers').append(el);markers.set(t,el);}return t;}
function specFromNet(data){const base=D.tanks.find(t=>t.id===data?.id)||chosen();return D.stats(base,data?.modules?D.moduleLevels(data.modules):Math.max(1,Math.min(5,Number(data?.level)||1)));}
function startBattle(options={}){
 if(!options.lan&&!save.owned[save.selected]){toast('Сначала исследуйте и купите танк');return;}countdown=5;countdownClock=null;aiming=false;$('hud').classList?.remove?.('aiming');Object.keys(keys).forEach(k=>keys[k]=false);$('countdown').hidden=false;$('countNumber').textContent='5';
 if(options instanceof Event)options={};initAudio();$('modal').hidden=true;$('garage').hidden=true;$('hud').hidden=false;state='battle';paused=false;matchMode=options.lan?'lan':'solo';arena=D.maps[options.map||save.map]||D.maps.training;setupScene(options.map||save.map);buildMap();tanks=[];markers.clear();$('markers').innerHTML='';elapsed=0;battleTime=arena.time;capture=0;viewYaw=matchMode==='lan'&&net?.role==='guest'?Math.PI:0;viewPitch=0;mouseDown=false;aiming=false;record={damage:0,kills:0,spotted:0,capture:0,life:0,win:false,survived:false};
 if(matchMode==='lan'){
  const hostSpec=specFromNet(options.host),guestSpec=specFromNet(options.guest),host=spawn(hostSpec,0,1,net.role==='host'),guest=spawn(guestSpec,1,1,net.role==='guest');player=net.role==='host'?host:guest;const remote=net.role==='host'?guest:host;remote.remote=true;remote.name=net.role==='host'?(net.guestName||'Соперник'):(net.hostName||'Хост');net.remote=remote;net.input={};netTick=0;
 }else{
  for(let i=0;i<3;i++){const s=i===1?D.stats(chosen(),save.modules[save.selected]):D.stats(D.tanks[chosen().n*3+i],save.levels[save.selected]);const t=spawn(s,0,i,i===1);if(i===1)player=t;}
  for(let i=0;i<3;i++)spawn(D.stats(D.tanks[3+i],Math.max(1,save.levels[save.selected]-(save.settings.difficulty==='easy'?1:0))),1,i);
 }
 viewYaw=player.yaw;
 $('playerName').textContent=player.spec.name.toUpperCase();$('mapName').textContent=arena.name.toUpperCase();$('killfeed').innerHTML='';$('hitMessage').textContent='';$('tutorialHint').textContent=matchMode==='lan'?'ЛОКАЛЬНАЯ СЕТЬ 1 × 1 · уничтожьте танк соперника':save.tutorial?'':'W / S — движение, A / D — поворот корпуса. Shift — оптика, ЛКМ — выстрел. База A находится в центре карты.';camera.position.copy(player.group.position).add(new V(0,7,-13));Platform.gameplay(true);updateHUD();
}
async function lanApi(path,data){const response=await fetch('/api/lan/'+path,{method:data?'POST':'GET',headers:data?{'Content-Type':'application/json'}:{},body:data?JSON.stringify(data):undefined,cache:'no-store'});const result=await response.json().catch(()=>({error:'Сервер не ответил'}));if(!response.ok)throw new Error(result.error||'Ошибка локальной сети');return result;}
function localSpec(){return {id:save.selected,level:save.levels[save.selected],modules:D.moduleLevels(save.modules[save.selected])};}
function closeLan(){if(net)netSend('leave',{});net=null;$('modal').hidden=true;}
function netSend(type,data){if(!net)return Promise.resolve();return lanApi('send',{code:net.code,token:net.token,type,data}).catch(()=>{});}
function lobbyView(){if(!net)return;const host=net.role==='host',ready=!!net.guest,players=net.players||[];$('modalContent').innerHTML=`<div class="eyebrow">ЛОКАЛЬНАЯ СЕТЬ · ${host?'ХОСТ':'ГОСТЬ'}</div><h2>Лобби 1 × 1</h2><div class="lan-code">${net.code}</div><p class="lan-status">${players.length<2?'Ожидание второго игрока…':'Соперник подключён: '+(players.find(p=>p.role!==net.role)?.name||'Командир')}</p>${host?`<p>Передайте другу код и адрес Radmin-сети:</p><p class="lan-address">${(net.addresses||[location.origin]).join('<br>')}</p><button id="copyInvite" class="secondary">КОПИРОВАТЬ ПРИГЛАШЕНИЕ</button><button id="lanStart" class="primary" ${ready?'':'disabled'}>НАЧАТЬ БОЙ →</button>`:'<p>Танк выбран. Ждём, когда хост начнёт бой.</p>'}<button id="lanClose" class="text-btn">← Покинуть лобби</button>`;$('lanClose').onclick=closeLan;if(host){$('copyInvite').onclick=async()=>{const text=`Стальной рубеж — лобби ${net.code}\n${(net.addresses||[location.origin])[0]}`;await navigator.clipboard?.writeText(text);toast('Приглашение скопировано');};$('lanStart').onclick=()=>{if(!net.guest)return;const payload={map:save.map,host:localSpec(),guest:net.guest};netSend('start',payload);startBattle({...payload,lan:true});};}}
async function lanPoll(){if(!net)return;try{const result=await lanApi(`poll?code=${encodeURIComponent(net.code)}&token=${encodeURIComponent(net.token)}&since=${net.since||0}`);net.since=result.seq;net.players=result.room.players;for(const message of result.messages)handleNetMessage(message);if(state==='garage'&&!$('modal').hidden)lobbyView();net.failures=0;}catch(error){if(net&&++net.failures>5){toast(error.message);if(state==='battle')endBattle(false,'Соединение с локальным сервером потеряно.');net=null;return;}}if(net)setTimeout(lanPoll,state==='battle'?70:350);}
function handleNetMessage(message){if(!net)return;if(message.type==='joined'){net.players=message.data.players;lobbyView();}else if(message.type==='ready'&&net.role==='host'){net.guest=message.data.spec;net.guestName=message.data.name;lobbyView();}else if(message.type==='start'&&net.role==='guest'){startBattle({...message.data,lan:true});}else if(message.type==='input'&&net.role==='host'){net.input=message.data||{};}else if(message.type==='snapshot'&&net.role==='guest'){applyNetSnapshot(message.data);}else if(message.type==='end'&&state==='battle'){endBattle(message.data.winner===player.team,message.data.reason||'Сетевой бой завершён.');}else if(message.type==='leave'){toast('Соперник покинул лобби');}}
async function createLan(){try{const info=await lanApi('info'),data=await lanApi('create',{name:'Командир'});net={...data,addresses:info.addresses?.length?info.addresses:[location.origin],since:0,players:data.players,failures:0};lobbyView();lanPoll();}catch(error){showModal(`<div class="eyebrow">ЛОКАЛЬНАЯ СЕТЬ</div><h2>Сервер не запущен</h2><p>${error.message}. Запустите игру через <b>PLAY.cmd</b>, а не прямым открытием index.html.</p><button id="lanBack" class="secondary">← Назад</button>`);$('lanBack').onclick=showLan;}}
async function joinLan(){const input=$('lanCode'),joinButton=$('lanJoin'),code=input.value.toUpperCase().replace(/[^A-Z2-9]/g,'');if(code.length!==5){input.focus();return;}joinButton.disabled=true;try{const data=await lanApi('join',{code,name:'Соперник'});net={...data,since:0,players:data.players,failures:0};netSend('ready',{spec:localSpec(),name:'Соперник'});lobbyView();lanPoll();}catch(error){$('lanError').textContent=error.message;joinButton.disabled=false;}}
function showLan(){showModal('<div class="eyebrow">ЛОКАЛЬНАЯ СЕТЬ · RADMIN VPN</div><h2>Бой 1 × 1</h2><p>Хост создаёт лобби и отправляет другу адрес сервера вместе с кодом. Оба игрока должны открыть игру через один и тот же компьютер-хост.</p><div class="lan-actions"><button id="lanCreate" class="primary">СОЗДАТЬ ЛОББИ</button><div><input id="lanCode" maxlength="5" placeholder="КОД" style="width:100%;padding:16px;background:#0d1a20;border:1px solid #ffffff25;color:#fff;text-transform:uppercase"><button id="lanJoin" class="secondary">ВОЙТИ ПО КОДУ</button></div></div><p id="lanError" class="enemy"></p><button id="lanCancel" class="text-btn">← Назад в ангар</button>');$('lanCreate').onclick=createLan;$('lanJoin').onclick=joinLan;$('lanCancel').onclick=()=>{$('modal').hidden=true;};$('lanCode').onkeydown=e=>{if(e.key==='Enter')joinLan();};}
function updateRemote(t,dt){const i=net?.input||{},accel=(i.w?1:0)-(i.s?1:0),turn=(i.a?1:0)-(i.d?1:0);t.yaw+=turn*t.spec.turn*dt*(t.trackTime?0:1);accelerateTank(t,accel,dt,turn);moveTank(t,dt);t.group.rotation.y=t.yaw;t.turretYaw=approach(t.turretYaw,Number.isFinite(i.yaw)?i.yaw:t.turretYaw,t.spec.turret*dt);t.turret.rotation.y=angle(t.turretYaw-t.yaw);t.remoteAim=!!i.aiming;t.aimBloom=D.aimStep(t.aimBloom,t.remoteAim,Math.min(1,Math.abs(t.speed)/Math.max(1,t.spec.speed)+Math.abs(turn)*.7),t.spec.aim,dt);if(Array.isArray(i.target)&&i.target.length===3){const target=new V(i.target[0],i.target[1],i.target[2]);aimGun(t,target,dt);if(i.fire)fire(t,target);}}
function netSnapshot(){return {time:battleTime,capture,countdown,tanks:tanks.map(t=>({team:t.team,x:t.group.position.x,y:t.group.position.y,z:t.group.position.z,yaw:t.yaw,turret:t.turretYaw,hp:t.hp,alive:t.alive,reload:t.reload,speed:t.speed,trackTime:t.trackTime,brokenSide:t.brokenSide,vy:t.suspension?.vy||0,grounded:t.suspension?.grounded!==false,pitch:t.group.rotation.x,roll:t.group.rotation.z}))};}
function applyNetSnapshot(data){if(!data?.tanks||state!=='battle')return;battleTime=data.time;capture=data.capture;for(const s of data.tanks){const t=tanks.find(v=>v.team===s.team);if(!t)continue;const previous=t.group.position.clone(),alpha=t.isPlayer?.22:.62;t.group.position.lerp(new V(s.x,s.y,s.z),alpha);t.yaw=angle(t.yaw+angle(s.yaw-t.yaw)*alpha);t.turretYaw=angle(t.turretYaw+angle(s.turret-t.turretYaw)*alpha);t.group.rotation.y=t.yaw;t.turret.rotation.y=angle(t.turretYaw-t.yaw);if(t.alive&&!s.alive)makeWreck(t);t.trackTime=s.trackTime||0;t.brokenSide=s.brokenSide;t.trackYaw=s.yaw;t.hp=s.hp;t.alive=s.alive;t.reload=s.reload;if(t.suspension){t.suspension.y=t.group.position.y;t.suspension.vy=s.vy||0;t.suspension.grounded=s.grounded!==false;}
 if(!t.isPlayer){t.speed=s.speed;Remaster.suspension(t,height,.1,Math.sign(t.speed)*previous.distanceTo(t.group.position));t.group.position.y=s.y;t.suspension.y=s.y;t.suspension.vy=s.vy||0;t.suspension.grounded=s.grounded!==false;t.group.rotation.x=s.pitch||0;t.group.rotation.z=s.roll||0;}}}
function networkStep(dt){if(matchMode!=='lan'||!net)return;netTick-=dt;if(net.role==='host'){for(const t of tanks)if(t.remote&&t.alive)updateRemote(t,dt);if(netTick<=0){netTick=.1;netSend('snapshot',netSnapshot());}}else if(netTick<=0){netTick=.055;netSend('input',{w:!!(keys.KeyW||keys.ArrowUp),s:!!(keys.KeyS||keys.ArrowDown),a:!!(keys.KeyA||keys.ArrowLeft),d:!!(keys.KeyD||keys.ArrowRight),yaw:viewYaw,aiming,fire:!!(mouseDown||keys.Space),target:[lastAimPoint.x,lastAimPoint.y,lastAimPoint.z]});}}
function los(a,b){const origin=a.group.position.clone().add(new V(0,2,0)),end=b.group.position.clone().add(new V(0,1.5,0));const direction=end.sub(origin),len=direction.length();ray.set(origin,direction.normalize());ray.far=len;return ray.intersectObjects(solidMeshes,false).length===0;}
const botRoles={capturer:'Захватчик',captureSupport:'Поддержка захвата',tactician:'Тактик',push:'Пуш',tacticalSupport:'Поддержка тактика',flanker:'Крыса'};
function createBrain(random=Math.random){return {role:Object.keys(botRoles)[Math.min(5,Math.floor(random()*6))],side:random()<.5?-1:1,memory:null,partner:null,goal:null,mode:'Сбор',flankStage:0};}
function botCover(t,threat,anchor,peek=false){
 const p=t.group.position,e=threat,choices=[];
 for(const o of obstacles){if(Math.hypot(o.x-p.x,o.z-p.z)>75||o.r<3)continue;
  const dx=o.x-e.x,dz=o.z-e.z,len=Math.hypot(dx,dz)||1,nx=dx/len,nz=dz/len;
  for(const side of peek?[-1,1]:[0]){const gap=o.r+4,point={x:o.x+nx*gap-nz*side*(o.r+5),z:o.z+nz*gap+nx*side*(o.r+5)};
   if(blocked(point.x,point.z,2.8))continue;
   const probe={group:{position:new V(point.x,height(point.x,point.z),point.z)}};
   const clear=los(probe,{group:{position:new V(e.x,e.y??height(e.x,e.z),e.z)}});
   if(clear!==peek)continue;
   choices.push({point,score:Math.hypot(point.x-p.x,point.z-p.z)+Math.hypot(point.x-anchor.x,point.z-anchor.z)*.4});
  }
 }
 choices.sort((a,b)=>a.score-b.score);return choices[0]?.point;
}
function botPlan(t,visible){
 const b=t.brain,p=t.group.position,role=b.role,allies=tanks.filter(a=>a!==t&&a.alive&&a.team===t.team);
 const base={x:b.side*5,z:t.team===0?-3:3},support=role==='captureSupport'||role==='tacticalSupport';
 if(support){const preferred=role==='captureSupport'?'capturer':'tactician';
  const valid=a=>a&&a.alive&&a.team===t.team&&a!==t;
  if(!valid(b.partner)||b.partner.brain?.role!==preferred){const candidates=allies.filter(a=>a.brain?.role===preferred);b.partner=candidates.sort((a,c)=>p.distanceToSquared(a.group.position)-p.distanceToSquared(c.group.position))[0]||(valid(b.partner)?b.partner:allies.find(a=>!['captureSupport','tacticalSupport'].includes(a.brain?.role)&&(!a.isPlayer||Math.abs(a.speed)>1||Math.hypot(a.group.position.x,a.group.position.z)<80)))||null;}
 }
 const anchor=b.partner?.group.position||p;
 // Only sensed enemies are eligible: partners do not grant vision through walls.
 const score=e=>{const q=e.group.position;let s=p.distanceTo(q);if(role==='capturer'||role==='captureSupport')s+=Math.hypot(q.x,q.z)*.9;if(support)s+=q.distanceTo(anchor)*1.3;if(e===t.target)s-=18;return s;};
 visible.sort((a,c)=>score(a)-score(c));const target=visible[0]||null;
 if(target!==t.target)t.aimTime=0;t.target=target;
 if(target){b.memory={x:target.group.position.x,y:target.group.position.y,z:target.group.position.z,yaw:target.yaw,until:elapsed+8};}
 if(b.memory&&b.memory.until<elapsed){b.memory=null;b.flankStage=0;b.flankGoal=null;}
 const threat=target?.group.position||b.memory,dist=threat?Math.hypot(p.x-threat.x,p.z-threat.z):Infinity;
 let goal=base,mode='Захват базы',pace=.85;
 const retreat=()=>({x:p.x+(p.x-threat.x)/Math.max(1,dist)*22,z:p.z+(p.z-threat.z)/Math.max(1,dist)*22});
 if(role==='capturer'){// Do not abandon a capture merely to chase an enemy.
  if(threat&&dist<28&&t.hp<t.spec.hp*.2){goal=botCover(t,threat,base)||retreat();mode='Сохранение машины';}
 }else if(role==='captureSupport'){
  goal=b.partner?{x:anchor.x+b.side*9,z:anchor.z+(t.team===0?-1:1)*7}:base;mode='Прикрытие захватчика';
  if(Math.hypot(anchor.x,anchor.z)<20&&!target){goal={x:-base.x,z:-base.z};mode='Совместный захват';}
  if(target&&Math.hypot(p.x,p.z)<65){goal=botCover(t,threat,anchor,t.reload<.7)||{x:p.x,z:p.z};mode='Огневая поддержка базы';}
 }else if(role==='push'){
  pace=1;goal=threat?{x:threat.x,z:threat.z}:base;mode='Прорыв';if(dist<15)goal={x:p.x,z:p.z};
 }else if(role==='tactician'||role==='tacticalSupport'){
  pace=.72;const protect=t.hp<t.spec.hp*.4||t.reload>.9;
  goal=role==='tacticalSupport'&&b.partner?{x:anchor.x+b.side*15,z:anchor.z+(t.team===0?-1:1)*12}:base;
  mode=role==='tacticalSupport'?'Прикрытие тактика':'Выход на позицию';
  if(threat){const cover=botCover(t,threat,role==='tacticalSupport'?anchor:p,!protect);
   goal=cover||(protect||dist<45?retreat():dist>95?{x:threat.x,z:threat.z}:{x:p.x,z:p.z});mode=protect?'Укрытие / перезарядка':'Выход для выстрела';
  }
 }else if(role==='flanker'){
  pace=.92;mode='Обход по флангу';
  if(threat){const heading=target?.yaw??b.memory.yaw,nx=Math.sin(heading),nz=Math.cos(heading);
   if(!b.flankGoal||b.flankStage===0){b.flankGoal={x:threat.x+nz*b.side*65-nx*15,z:threat.z-nx*b.side*65-nz*15};b.flankStage=1;}
   if(b.flankStage===1&&Math.hypot(p.x-b.flankGoal.x,p.z-b.flankGoal.z)<14)b.flankStage=2;
   goal=b.flankStage===1?b.flankGoal:{x:threat.x-nx*32,z:threat.z-nz*32};mode=b.flankStage===1?'Обход по флангу':'Атака в корму';
  }else{const side=t.team===0?-1:1;goal=b.flankStage===0?{x:b.side*arena.size*.27,z:side*arena.size*.12}:base;if(Math.hypot(p.x-goal.x,p.z-goal.z)<15)b.flankStage=1;}
 }
 const limit=arena.size*.44;goal={x:Math.max(-limit,Math.min(limit,goal.x)),z:Math.max(-limit,Math.min(limit,goal.z))};
 if(!b.goal||Math.hypot(goal.x-b.goal.x,goal.z-b.goal.z)>9)t.navTime=0;
 b.goal=goal;b.mode=mode;b.pace=pace;
}
function updateBot(t,dt){
 const p=t.group.position;t.think-=dt;t.navTime-=dt;const difficulty=save.settings.difficulty;const cfg=difficulty==='easy'?{reaction:.9,spread:.055,aggression:.7}:difficulty==='hard'?{reaction:.26,spread:.016,aggression:1}:{reaction:.55,spread:.031,aggression:.87};
 t.brain??=createBrain();
 if(t.think<=0){t.think=.45+rand()*.3;const enemies=tanks.filter(e=>e.alive&&e.team!==t.team&&p.distanceTo(e.group.position)<D.detectionRange(t.spec,e.spec,Math.abs(e.speed)>1,e.revealTime>0)&&los(t,e));botPlan(t,enemies);}
 const goal=t.brain.goal||{x:0,z:0};
 if(t.target&&(!t.target.alive||!los(t,t.target))){t.target=null;t.aimTime=0;}
 if(t.target){const e=t.target.group.position,dist=p.distanceTo(e),bearing=Math.atan2(e.x-p.x,e.z-p.z);t.turretYaw=approach(t.turretYaw,bearing,t.spec.turret*dt);t.aimTime+=dt;
  const friendly=tanks.some(a=>a!==t&&a.team===t.team&&p.distanceTo(a.group.position)<dist&&D.segmentCircle(p.x,p.z,e.x,e.z,a.group.position.x,a.group.position.z,a.width*.6));
  if(!friendly&&t.aimTime>cfg.reaction&&Math.abs(angle(bearing-t.turretYaw))<.09&&t.reload<=0){const lead=Math.min(.6,dist/D.shellSpeed),q=e.clone().add(new V(Math.sin(t.target.yaw)*t.target.speed*lead+(rand()-.5)*dist*cfg.spread,1.45+(rand()-.5)*.5,Math.cos(t.target.yaw)*t.target.speed*lead+(rand()-.5)*dist*cfg.spread));fire(t,q);t.aimTime=0;t.think=0;}
 }else{t.turretYaw=approach(t.turretYaw,t.yaw,t.spec.turret*dt);t.aimTime=0;}
 if(Math.hypot(goal.x-p.x,goal.z-p.z)>5){if(t.navTime<=0){t.path=route(p.x,p.z,goal.x,goal.z);t.navTime=1.6+rand();}while(t.path.length&&Math.hypot(t.path[0].x-p.x,t.path[0].z-p.z)<3.7)t.path.shift();const next=t.path[0]||goal;const desired=Math.atan2(next.x-p.x,next.z-p.z);const turn=angle(desired-t.yaw);t.yaw=approach(t.yaw,desired,t.spec.turn*dt);accelerateTank(t,t.stuck>1.5?-.6:cfg.aggression*t.brain.pace*Math.max(.08,1-Math.abs(turn)/1.8),dt,turn);if(!moveTank(t,dt)){t.stuck+=dt;t.yaw+=dt*(t.team===0?1:-1);if(t.stuck>1.5){t.path=[];t.navTime=0;if(t.stuck>3)t.stuck=0;}}else t.stuck=0;}else{accelerateTank(t,0,dt);moveTank(t,dt);}
 t.group.rotation.y=t.yaw;t.turret.rotation.y=angle(t.turretYaw-t.yaw);if(t.target){const e=t.target.group.position;aimGun(t,e.clone().add(new V(0,1.4,0)),dt);}
}
function vehicleEffects(t,dt,moved){t.effectClock-=dt;t.markClock-=dt;const p=t.group.position;if(t.effectClock<=0){t.effectClock=moved?.09:.28;const rear=new V(-Math.sin(t.yaw)*t.length*.44,1.35,-Math.cos(t.yaw)*t.length*.44).add(p);smoke(rear,moved?(arena===D.maps.winter?0xd7e0df:0x9d927b):0x5d6460,moved?.18:.11,moved?1.1:.55);if(moved){for(const side of [-1,1]){const dust=p.clone().add(new V(Math.cos(t.yaw)*side*t.width*.55,.12,-Math.sin(t.yaw)*side*t.width*.55));smoke(dust,arena===D.maps.winter?0xe1e7e5:arena===D.maps.desert?0xc5a879:0x817963,.24,1.8);}}}if(moved&&Math.abs(t.speed)>1&&t.markClock<=0){t.markClock=.16;for(const side of [-1,1]){const mark=new THREE.Mesh(trackGeo,trackMat);mark.rotation.x=-Math.PI/2;mark.rotation.z=-t.yaw;mark.position.set(p.x+Math.cos(t.yaw)*side*t.width*.5,height(p.x,p.z)+.035,p.z-Math.sin(t.yaw)*side*t.width*.5);mark.renderOrder=-1;world.add(mark);trackMarks.push({mesh:mark,life:32});}while(trackMarks.length>260){world.remove(trackMarks.shift().mesh);}}}
function groundSurface(){return arena===D.maps.winter?D.surfaces.snow:arena===D.maps.desert?D.surfaces.sand:D.surfaces.earth;}
function accelerateTank(t,throttle,dt,turn=0){
 if(t.suspension?.grounded===false)return;
 const p=t.group.position,dx=Math.sin(t.yaw)*2,dz=Math.cos(t.yaw)*2,slope=(height(p.x+dx,p.z+dz)-height(p.x-dx,p.z-dz))/4;
 t.speed=D.driveSpeed(t.spec,t.speed,throttle,slope,dt,turn,t.trackTime>0,groundSurface());
}
function moveTank(t,dt){
 if(t.trackTime>0){t.speed=0;t.slip=0;t.velocityX=0;t.velocityZ=0;t.yaw=t.trackYaw??t.yaw;t.group.rotation.y=t.yaw;Remaster.suspension(t,height,dt,0);return false;}
 const p=t.group.position,airborne=t.suspension?.grounded===false;
 if(airborne)t.yaw=t.suspension.yaw; // Tracks cannot steer a tank without ground contact.
 const sn=Math.sin(t.yaw),cs=Math.cos(t.yaw),surface=groundSurface();
 if(!airborne){
  const slope=(height(p.x+cs*2,p.z-sn*2)-height(p.x-cs*2,p.z+sn*2))/4;
  t.slip=D.frictionSpeed(t.slip||0,slope,dt,Math.abs(t.slip||0)<.001?surface.static:surface.kinetic);
  const total=Math.hypot(t.speed,t.slip);if(total>t.spec.speed){t.speed*=t.spec.speed/total;t.slip*=t.spec.speed/total;}
  t.velocityX=sn*t.speed+cs*t.slip;t.velocityZ=cs*t.speed-sn*t.slip;
 }
 const dx=(t.velocityX||0)*dt,dz=(t.velocityZ||0)*dt,r=t.width*.65,oldX=p.x,oldZ=p.z;
 const blockedByTank=(x,z)=>tanks.some(o=>o!==t&&(o.alive||o.wreck)&&Math.abs(p.y-o.group.position.y)<3&&Remaster.overlaps(t,x,z,o));
 if(!blocked(p.x+dx,p.z,r)&&!blockedByTank(p.x+dx,p.z))p.x+=dx;else t.velocityX=0;
 if(!blocked(p.x,p.z+dz,r)&&!blockedByTank(p.x,p.z+dz))p.z+=dz;else t.velocityZ=0;
 const travelled=Math.hypot(p.x-oldX,p.z-oldZ),didMove=travelled>.00001;
 t.speed=(t.velocityX||0)*sn+(t.velocityZ||0)*cs;t.slip=(t.velocityX||0)*cs-(t.velocityZ||0)*sn;
 Remaster.suspension(t,height,dt,airborne?0:(p.x-oldX)*sn+(p.z-oldZ)*cs);
 if(t.suspension.impact>2){if(t.isPlayer)shake=Math.min(.45,t.suspension.impact*.025);smoke(p.clone().add(new V(0,.2,0)),0x938577,.5,2);}
 if(t.alive&&t.suspension.grounded)vehicleEffects(t,dt,didMove);
 return didMove;
}
function aimGun(t,target,dt){
 t.group.updateMatrixWorld(true);
 const local=t.turret.worldToLocal(target.clone()).sub(t.gunPivot.position);
 const desired=THREE.MathUtils.clamp(-Math.atan2(local.y,Math.max(2.5,Math.hypot(local.x,local.z))),-.32,.22);
 t.gunPivot.rotation.x+=THREE.MathUtils.clamp(desired-t.gunPivot.rotation.x,-.65*dt,.65*dt);
}
function muzzlePos(t){t.group.updateMatrixWorld(true);return t.gunPivot.localToWorld(new V(0,0,t.barrelLength+.5));}
function aimPoint(){ray.setFromCamera(new THREE.Vector2(0,0),camera);ray.far=800;const targets=[ground,...solidMeshes,...tanks.filter(t=>t!==player&&(t.wreck||t.visible)&&(t.alive||t.wreck)).flatMap(t=>[...t.hitMeshes,...(t.wreckCollider?[t.wreckCollider]:[])] )];const hit=ray.intersectObjects(targets,false)[0];aimHit=hit||null;return hit?hit.point:ray.ray.at(750,new V());}
function fire(t,target){if(countdown>0||t.reload>0||!t.alive)return;t.reload=t.spec.reload;t.revealTime=3.5;const origin=muzzlePos(t),delta=target.clone().sub(origin),horizontal=Math.hypot(delta.x,delta.z);delta.y+=D.shellDrop(horizontal);const direction=delta.normalize(),actualYaw=Math.atan2(direction.x,direction.z);if(t.isPlayer&&Math.abs(angle(actualYaw-t.turretYaw))>.09){direction.x=Math.sin(t.turretYaw);direction.z=Math.cos(t.turretYaw);direction.normalize();}const bloom=t.aimBloom??(t.target?Math.max(.2,1-t.aimTime/Math.max(.2,t.spec.aim)):.8),spread=t.spec.spread*(.34+bloom*1.28);direction.x+=(Math.random()-.5)*spread;direction.y+=(Math.random()-.5)*spread*.55;direction.z+=(Math.random()-.5)*spread;direction.normalize();const bullet=mesh(new THREE.CapsuleGeometry(.075,.55,2,5),new THREE.MeshBasicMaterial({color:0xfff0ad}),world);bullet.position.copy(origin);bullet.quaternion.setFromUnitVectors(up,direction);bullets.push({mesh:bullet,position:origin.clone(),velocity:direction.multiplyScalar(D.shellSpeed),owner:t,life:4.2,ricochets:0,gravityScale:D.shellGravity});t.aimBloom=1;burst(origin,0xffce79,15,.2);smoke(origin,0x77746d,.35,1.8);const flash=new THREE.PointLight(0xffb45c,28,22,2);flash.position.copy(origin);world.add(flash);particles.push({mesh:flash,velocity:new V(),life:.09,max:.09,size:1,gravity:0});sound('shot',t.isPlayer?1:.25);if(t.isPlayer)shake=.16;}
function burst(position,color,count=16,size=.5){for(let i=0;i<count;i++){const o=mesh(sphereGeo,mat(color),world);o.position.copy(position);const life=.35+Math.random()*.55;o.scale.setScalar(size*(.5+Math.random()));particles.push({mesh:o,velocity:new V((Math.random()-.5)*9,Math.random()*7,(Math.random()-.5)*9),life,max:life,size:o.scale.x});}}
function smoke(position,color,size=.3,speed=1){const material=new THREE.MeshBasicMaterial({color,transparent:true,opacity:.34,depthWrite:false});const o=mesh(sphereGeo,material,world);o.position.copy(position);o.scale.set(size,size*.65,size);const life=.8+Math.random()*.9;particles.push({mesh:o,velocity:new V((Math.random()-.5)*speed,.45+Math.random()*speed*.7,(Math.random()-.5)*speed),life,max:life,size,gravity:-.12,grow:1.8,fade:true});}
function addImpactHole(t,point,normal,amount){if(!normal)return;const material=new THREE.MeshBasicMaterial({color:amount>180?0x080807:0x171817,transparent:true,opacity:.92,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-4});const hole=new THREE.Mesh(holeGeo,material),local=t.group.worldToLocal(point.clone()),q=t.group.getWorldQuaternion(new THREE.Quaternion()).invert(),n=normal.clone().applyQuaternion(q).normalize();hole.position.copy(local).addScaledVector(n,.025);hole.scale.setScalar(amount>180?.19:.11);hole.lookAt(local.clone().add(n));t.group.add(hole);t.holes.push(hole);while(t.holes.length>28){const old=t.holes.shift();t.group.remove(old);old.material.dispose();}}
function makeWreck(t){if(t.wreck)return;t.wreck=true;t.alive=false;t.speed=0;t.group.visible=true;const wreckMaterial=mat(0x353b38,.32,.96);wreckMaterial.transparent=false;wreckMaterial.opacity=1;wreckMaterial.depthWrite=true;wreckMaterial.depthTest=true;t.group.traverse(o=>{if(!o.isMesh||o.userData.collisionOnly||t.holes.includes(o))return;o.visible=true;o.material=Array.isArray(o.material)?o.material.map(()=>wreckMaterial):wreckMaterial;});}
function damageTank(t,amount,owner,point,normal){if(!t.alive||t.team===owner.team)return;let damage=Math.round(amount*(1-t.spec.armor/100)*(.91+Math.random()*.18));const crit=Math.random()<.08; if(crit){damage=Math.round(damage*1.25);}damage=Math.min(t.hp,damage);t.hp-=damage;if(t.isPlayer&&damage>0){capture=0;hitText('ЗАХВАТ СБРОШЕН');}addImpactHole(t,point,normal,amount);if(owner.isPlayer){record.damage+=damage;hitText((crit?'КРИТИЧЕСКОЕ ПОПАДАНИЕ  ':'ПОПАДАНИЕ  ')+damage);sound('hit');}if(t.isPlayer){shake=.22;$('damageFlash').style.opacity=1;setTimeout(()=>$('damageFlash').style.opacity=0,160);}burst(point,0xffd487,18,.23);smoke(point,0x403d38,.32,1.2);if(t.hp<=0){makeWreck(t);burst(t.group.position.clone().add(new V(0,1,0)),0xdb8942,36,1.1);for(let i=0;i<8;i++)smoke(t.group.position.clone().add(new V((Math.random()-.5)*2,1+Math.random(),(Math.random()-.5)*2)),0x343532,.7,1.7);sound('boom',t.isPlayer?1:.55);if(owner.isPlayer){record.kills++;hitText('ПРОТИВНИК УНИЧТОЖЕН');}const line=document.createElement('div');line.textContent=`${owner.name} › ${t.name} · ${t.spec.name}`;line.style.color=owner.team===0?'#99d2c6':'#e99880';$('killfeed').prepend(line);while($('killfeed').children.length>5)$('killfeed').lastChild.remove();if(t.isPlayer){record.life=elapsed;$('tutorialHint').textContent='Танк уничтожен. Бой продолжается.';document.exitPointerLock?.();mouseDown=false;}}}
function hitText(text){$('hitMessage').textContent=text;clearTimeout(hitTimer);hitTimer=setTimeout(()=>$('hitMessage').textContent='',1300);}
function updateProjectiles(dt){
 world.updateMatrixWorld(true);
 for(let i=bullets.length-1;i>=0;i--){
  const b=bullets[i];b.velocity.y-=D.gravity*(b.gravityScale??D.shellGravity)*dt;const direction=b.velocity.clone().normalize(),distance=b.velocity.length()*dt;ray.set(b.position,direction);ray.far=distance;
  const targets=tanks.filter(t=>t!==b.owner&&(t.alive||t.wreck)).flatMap(t=>[...t.hitMeshes,...(t.wreckCollider?[t.wreckCollider]:[])]),hit=ray.intersectObjects([ground,...solidMeshes,...targets],false)[0];
  b.life-=dt;let consumed=false,ricocheted=false;
  if(hit){
   const t=hit.object.userData.tank,normal=hit.face?.normal.clone().transformDirection(hit.object.matrixWorld).normalize();if(normal&&normal.dot(direction)>0)normal.negate();
   if(t&&!t.wreck){
    const zone=Remaster.zone(hit,t),incidence=normal?Math.abs(normal.dot(direction)):1,result=D.penetration(b.owner.spec,t.spec,zone,incidence,b.owner.group.position.distanceTo(hit.point));
    if(Math.random()<result.chance){damageTank(t,b.owner.spec.damage,b.owner,hit.point,normal);if(zone==='tracks'&&t.team!==b.owner.team&&t.alive){t.trackTime=10;t.brokenSide=t.group.worldToLocal(hit.point.clone()).x<0?-1:1;t.speed=0;t.slip=0;t.trackYaw=t.yaw;if(t.isPlayer||b.owner.isPlayer)hitText('ГУСЕНИЦА СБИТА · РЕМОНТ 10 С');}consumed=true;}
    else if(normal){const bounce=D.ricochetVelocity(b.velocity,normal,incidence,b.ricochets);if(bounce){
     b.velocity.set(bounce.x,bounce.y,bounce.z);b.position.copy(hit.point).addScaledVector(b.velocity.clone().normalize(),.42);b.mesh.position.copy(b.position);b.mesh.quaternion.setFromUnitVectors(up,b.velocity.clone().normalize());b.ricochets++;b.life=Math.min(b.life,1.15);ricocheted=true;burst(hit.point,0xffd27a,22,.12);addImpactHole(t,hit.point,normal,35);if(b.owner.isPlayer)hitText('РИКОШЕТ · '+Math.round(Math.acos(incidence)*180/Math.PI)+'°');
    }else{burst(hit.point,0xffe1a0,14,.1);addImpactHole(t,hit.point,normal,50);if(b.owner.isPlayer)hitText('НЕ ПРОБИТО');consumed=true;}}
   }else{burst(hit.point,t?0xffe1a0:0xffdf9a,14,.16);if(!t)smoke(hit.point,0x6d675b,.25,1.1);consumed=true;}
  }
  if(consumed||b.life<=0){world.remove(b.mesh);b.mesh.geometry.dispose();b.mesh.material.dispose();bullets.splice(i,1);}else if(!ricocheted){b.position.addScaledVector(b.velocity,dt);b.mesh.position.copy(b.position);b.mesh.quaternion.setFromUnitVectors(up,b.velocity.clone().normalize());}
 }
 for(let i=particles.length-1;i>=0;i--){const p=particles[i];p.life-=dt;if(p.life<=0){world.remove(p.mesh);if(p.fade)p.mesh.material?.dispose?.();particles.splice(i,1);}else{p.velocity.y-=(p.gravity??D.gravity)*dt;p.mesh.position.addScaledVector(p.velocity,dt);if(!p.fade&&p.mesh.isMesh){const floor=height(p.mesh.position.x,p.mesh.position.z)+p.size*.25;if(p.mesh.position.y<floor){p.mesh.position.y=floor;p.velocity.y=Math.max(0,-p.velocity.y*.22);const drag=Math.exp(-groundSurface().kinetic*D.gravity*dt);p.velocity.x*=drag;p.velocity.z*=drag;}}const ratio=p.life/p.max,scale=p.grow?p.size*(1+(1-ratio)*p.grow):p.size*ratio;p.mesh.scale.setScalar(scale);if(p.fade&&p.mesh.material)p.mesh.material.opacity=.34*ratio;}}
 for(let i=trackMarks.length-1;i>=0;i--){const m=trackMarks[i];m.life-=dt;if(m.life<5)m.mesh.material=trackMat;if(m.life<=0){world.remove(m.mesh);trackMarks.splice(i,1);}}
}
function updateCamera(dt){const focus=player.alive?player:tanks.find(t=>t.alive&&t.team===player.team)||player;const p=focus.group.position;if(!player.alive)viewYaw+=dt*.045;const scoped=aiming&&player.alive,d=scoped?-Math.max(3,focus.length*.55):12,targetDistance=aiming?90:23;const target=p.clone().add(new V(Math.sin(viewYaw)*targetDistance,2.2+viewPitch*targetDistance,Math.cos(viewYaw)*targetDistance));const desired=p.clone().add(new V(-Math.sin(viewYaw)*d,scoped?2.65:6.4,-Math.cos(viewYaw)*d));const pivot=p.clone().add(new V(0,2.6,0));ray.set(pivot,desired.clone().sub(pivot).normalize());ray.far=desired.distanceTo(pivot);const obstruction=ray.intersectObjects(solidMeshes,false)[0];if(obstruction)desired.copy(ray.ray.at(Math.max(1,obstruction.distance-.6),new V()));desired.y=Math.max(desired.y,height(desired.x,desired.z)+1.5);if(scoped)camera.position.copy(desired);else camera.position.lerp(desired,1-Math.exp(-dt*10));if(shake>0){camera.position.x+=(Math.random()-.5)*shake;camera.position.y+=(Math.random()-.5)*shake;shake*=Math.exp(-dt*11);}const zoom=player?.spec.zoom||2.5,cameraFov=aiming?Math.max(12,60/zoom):60;camera.fov=THREE.MathUtils.lerp(camera.fov,cameraFov,1-Math.exp(-dt*(aiming?7:10)));camera.updateProjectionMatrix();camera.lookAt(target);}
function updateBattle(dt,frameTime){
 if(countdown>0){const delta=countdownClock===null?0:Math.max(0,(frameTime-countdownClock)/1000);countdownClock=frameTime;countdown=Math.max(0,countdown-delta);$('countNumber').textContent=Math.ceil(countdown);$('countdown').hidden=countdown<=0;updateCamera(dt);if(countdown===0){mouseDown=false;Object.keys(keys).forEach(k=>keys[k]=false);}return;}
 aiming=!!(keys.ShiftLeft||keys.ShiftRight);$('hud').classList?.toggle('aiming',aiming);elapsed+=dt;battleTime=Math.max(0,battleTime-dt);if(player.alive)record.life=elapsed;
 for(const t of tanks){if(!t.alive){accelerateTank(t,0,dt);moveTank(t,dt);continue;}t.reload=Math.max(0,t.reload-dt);t.revealTime=Math.max(0,(t.revealTime||0)-dt);t.trackTime=Math.max(0,t.trackTime-dt);if(t.isPlayer){const accel=(keys.KeyW||keys.ArrowUp?1:0)-(keys.KeyS||keys.ArrowDown?1:0);const turn=(keys.KeyA||keys.ArrowLeft?1:0)-(keys.KeyD||keys.ArrowRight?1:0);t.yaw+=turn*t.spec.turn*dt*(t.trackTime?0:1);accelerateTank(t,accel,dt,turn);moveTank(t,dt);t.group.rotation.y=t.yaw;t.turretYaw=approach(t.turretYaw,viewYaw,t.spec.turret*dt);t.turret.rotation.y=angle(t.turretYaw-t.yaw);t.aimBloom=D.aimStep(t.aimBloom,aiming,Math.min(1,Math.abs(t.speed)/Math.max(1,t.spec.speed)+Math.abs(turn)*.72),t.spec.aim,dt);lastAimPoint.copy(aimPoint());aimGun(t,lastAimPoint,dt);if((mouseDown||keys.Space)&&!(matchMode==='lan'&&net?.role==='guest'))fire(t,lastAimPoint);}else if(!t.remote)updateBot(t,dt);}
 networkStep(dt);updateProjectiles(dt);updateCamera(dt);
 const onBase=tanks.filter(t=>t.alive&&t.suspension?.grounded!==false&&Math.hypot(t.group.position.x,t.group.position.z)<12),a=onBase.filter(t=>t.team===0).length,b=onBase.filter(t=>t.team===1).length;if(a&&!b){capture=Math.min(100,capture+dt*3*a);if(onBase.includes(player))record.capture+=dt;}else if(b&&!a)capture=Math.max(-100,capture-dt*3*b);else if(!a&&!b)capture*=Math.exp(-dt*.015);
 const allies=tanks.filter(t=>t.alive&&t.team===0),enemies=tanks.filter(t=>t.alive&&t.team===1);if(!(matchMode==='lan'&&net?.role==='guest')){if(!enemies.length||capture>=100){endBattle(true,capture>=100?'База под контролем вашей команды':'Все противники уничтожены');return;}if(!allies.length||capture<=-100){endBattle(false,capture<=-100?'Противник захватил базу':'Ваша команда уничтожена');return;}if(battleTime<=0){const aHP=allies.reduce((s,t)=>s+t.hp/t.spec.hp,0),bHP=enemies.reduce((s,t)=>s+t.hp/t.spec.hp,0);endBattle(aHP>bHP,'Время вышло. Итог по оставшейся прочности команд.');return;}}
 uiTick+=dt;if(uiTick>.1){uiTick=0;updateHUD();if(matchMode==='lan'&&player.team===1){$('alliesScore').textContent=tanks.filter(t=>t.alive&&t.team===1).length;$('enemiesScore').textContent=tanks.filter(t=>t.alive&&t.team===0).length;}}updateMarkers();if(engineGain){engineGain.gain.value=player.alive?.025+Math.abs(player.speed)*.0018:0;engineAudio.frequency.value=35+Math.abs(player.speed)*3;}
}
function updateMarkers(){for(const [t,el]of markers){if(!t.alive){el.hidden=true;continue;}const friendly=t.team===player.team,dist=player.group.position.distanceTo(t.group.position),visible=friendly||(dist<D.detectionRange(player.spec,t.spec,Math.abs(t.speed)>1,t.revealTime>0)&&los(player,t));el.className='marker '+(friendly?'friendly':'');if(visible&&!friendly&&!t.seen&&player.alive){t.seen=true;record.spotted++;}t.visible=visible;t.group.visible=visible;const point=t.group.position.clone().add(new V(0,4.1,0)).project(camera);el.hidden=!visible||point.z>1||point.z<0||Math.abs(point.x)>1.15||Math.abs(point.y)>1.15;if(!el.hidden){el.style.left=(point.x*.5+.5)*innerWidth+'px';el.style.top=(-point.y*.5+.5)*innerHeight+'px';el.innerHTML=`${friendly?'◆':'◇'} ${t.spec.name}<div><i style="width:${t.hp/t.spec.hp*100}%"></i></div>${Math.ceil(t.hp)} · ${Math.round(dist)} м`;}}}
function updatePenetration(){const dot=$('penetrationDot'),label=$('penetrationLabel'),t=aimHit?.object.userData.tank;if(!t||!t.alive||t.team===player.team){dot.style.background='#dbe2dc';label.textContent=aiming?player.spec.zoom.toFixed(1)+'×':'';return;}const normal=aimHit.face?.normal.clone().transformDirection(aimHit.object.matrixWorld),direction=aimHit.point.clone().sub(muzzlePos(player)).normalize(),result=D.penetration(player.spec,t.spec,Remaster.zone(aimHit,t),normal?Math.abs(normal.dot(direction)):1,player.group.position.distanceTo(aimHit.point));dot.style.background=result.color;dot.style.boxShadow='0 0 12px '+result.color;label.style.color=result.color;label.textContent=(result.chance>=.75?'ПРОБИТИЕ':result.chance>=.25?'РИСК НЕПРОБИТИЯ':'БРОНЯ НЕ ПРОБИВАЕТСЯ')+' · '+Math.round(result.chance*100)+'%';}
function updateHUD(){updatePenetration();const a=tanks.filter(t=>t.alive&&t.team===0).length,b=tanks.filter(t=>t.alive&&t.team===1).length;$('alliesScore').textContent=a;$('enemiesScore').textContent=b;$('timer').textContent=`${Math.floor(battleTime/60).toString().padStart(2,'0')}:${Math.floor(battleTime%60).toString().padStart(2,'0')}`;$('hpText').textContent=`${Math.ceil(player.hp)} / ${player.spec.hp}`;$('hpBar').style.width=player.hp/player.spec.hp*100+'%';$('speedText').textContent=player.trackTime>0?'ГУСЕНИЦА · '+Math.ceil(player.trackTime)+' С':Math.round(Math.abs(player.speed)*3.6)+' км/ч';$('reloadLabel').textContent=!player.alive?'МАШИНА УНИЧТОЖЕНА':player.reload>.05?`ПЕРЕЗАРЯДКА ${player.reload.toFixed(1)} с`:'ОРУДИЕ ГОТОВО';$('reloadBar').style.width=(1-player.reload/player.spec.reload)*100+'%';$('objectiveText').textContent=Math.abs(capture)>1?`${capture>0?'ВАША КОМАНДА':'ПРОТИВНИК'} · БАЗА A ${Math.floor(Math.abs(capture))}%`:'ЗАХВАТИТЕ БАЗУ A';$('captureBar').style.width=Math.abs(capture)+'%';$('captureBar').style.background=capture>=0?'#80c7c0':'#e78c72';$('sightReady').textContent=player.reload>.05?player.reload.toFixed(1)+' с':'Готов';$('sightHealth').textContent=Math.round(player.hp/player.spec.hp*100)+'%';const settled=Math.round((1-(player.aimBloom||1))*100);$('range').textContent=player.reload>.05?`${player.reload.toFixed(1)} С`:`${Math.round(player.group.position.distanceTo(lastAimPoint))} М · СВЕДЕНИЕ ${settled}%`;document.querySelector('.reticle').style.transform=`scale(${.42+(player.aimBloom||1)*.88})`;drawMinimap();if(elapsed>22&&!save.tutorial){save.tutorial=true;persist();$('tutorialHint').textContent='';}}
function drawMinimap(){const ctx=$('minimap').getContext('2d'),size=220,scale=size/arena.size;ctx.fillStyle=arena===D.maps.desert?'#655d47':arena===D.maps.winter?'#56686e':'#394d43';ctx.fillRect(0,0,size,size);ctx.strokeStyle='#ffffff0e';ctx.lineWidth=1;for(let i=0;i<=5;i++){ctx.beginPath();ctx.moveTo(i*44,0);ctx.lineTo(i*44,220);ctx.moveTo(0,i*44);ctx.lineTo(220,i*44);ctx.stroke();}const X=x=>110+x*scale,Z=z=>110-z*scale;ctx.fillStyle='#adbaab50';for(const o of obstacles){ctx.beginPath();ctx.arc(X(o.x),Z(o.z),o.r*scale,0,Math.PI*2);ctx.fill();}ctx.strokeStyle='#ddc88b';ctx.beginPath();ctx.arc(110,110,12*scale,0,Math.PI*2);ctx.stroke();ctx.fillStyle='#eddbab';ctx.font='11px sans-serif';ctx.fillText('A',107,114);for(const t of tanks){if(!t.alive||(t.team===1&&!t.visible))continue;ctx.save();ctx.translate(X(t.group.position.x),Z(t.group.position.z));ctx.rotate(t.yaw);ctx.fillStyle=t.isPlayer?'#fff0ba':t.team===0?'#83d0c1':'#ef997a';ctx.beginPath();ctx.moveTo(0,-5);ctx.lineTo(4,4);ctx.lineTo(-4,4);ctx.closePath();ctx.fill();if(t.isPlayer){ctx.strokeStyle='#fff0ba70';ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(-11,-24);ctx.moveTo(0,0);ctx.lineTo(11,-24);ctx.stroke();}ctx.restore();}}
function endBattle(win,reason){if(state!=='battle')return;if(matchMode==='lan'&&net?.role==='host')netSend('end',{winner:win?player.team:1-player.team,reason});updateHUD();state='result';paused=false;Platform.gameplay(false);document.exitPointerLock?.();mouseDown=false;record.win=win;record.survived=player.alive;const reward=D.reward(record);save.silver+=reward.silver;save.xp+=reward.xp;save.battles++;if(win)save.wins++;persist();if(engineGain)engineGain.gain.value=0;$('scoreboard').hidden=true;showModal(`<div class="end-medal">${win?'◈':'◇'}</div><div class="result-title"><small>ОПЕРАЦИЯ ЗАВЕРШЕНА</small><h2>${win?'Победа':'Поражение'}</h2><p>${reason}</p></div><div class="row"><span>Нанесённый урон</span><b>${record.damage}</b></div><div class="row"><span>Уничтожено / обнаружено</span><b>${record.kills} / ${record.spotted}</b></div><div class="row"><span>Время жизни / захват базы</span><b>${Math.floor(record.life)} с / ${Math.floor(record.capture)} с</b></div><div class="reward"><div>+${reward.silver} ◉<small>СЕРЕБРО</small></div><div>+${reward.xp} ✦<small>ОПЫТ</small></div></div><p class="help-note">Участие ${reward.parts.participation} · урон ${reward.parts.damage} · фраги ${reward.parts.kills} · победа ${reward.parts.victory} · разведка ${reward.parts.spotting} · база ${reward.parts.objective} · выживание ${reward.parts.survival}</p><button id="returnGarage" class="primary">В АНГАР →</button>`);$('returnGarage').onclick=()=>{net=null;matchMode='solo';hangar();};}
function showModal(html){$('modalContent').innerHTML=html;$('modal').hidden=false;}
function pause(){if(state!=='battle'||paused)return;if(matchMode==='lan'){toast('Сетевой бой нельзя поставить на паузу');return;}paused=true;countdownClock=null;mouseDown=false;aiming=false;$('hud').classList?.remove?.('aiming');Object.keys(keys).forEach(k=>keys[k]=false);Platform.gameplay(false);document.exitPointerLock?.();if(engineGain)engineGain.gain.value=0;showModal('<div class="eyebrow">БОЙ ПРИОСТАНОВЛЕН</div><h2>Пауза</h2><p>Ваш танк и команды ждут возвращения.</p><button id="resume" class="primary">ПРОДОЛЖИТЬ →</button><button id="pauseSettings" class="secondary">Настройки</button><button id="leave" class="text-btn">Завершить бой и получить награду</button>');$('resume').onclick=resume;$('pauseSettings').onclick=settings;$('leave').onclick=()=>endBattle(false,'Досрочный выход из боя. Награда за участие начислена.');}
function resume(){paused=false;$('modal').hidden=true;initAudio();Platform.gameplay(true);}
function settings(){const inBattle=state==='battle';showModal(`<div class="eyebrow">ПАРАМЕТРЫ</div><h2>Настройки</h2><label for="volume">Громкость</label><input id="volume" type="range" min="0" max="1" step=".05" value="${save.settings.volume}"><label for="quality">Графика</label><select id="quality"><option value="high">Максимальная — PBR, AO, тени 4K</option><option value="low">Производительность — без постобработки</option></select><label for="difficulty">Боты — со следующего боя</label><select id="difficulty"><option value="easy">Лёгкие</option><option value="normal">Обычные</option><option value="hard">Сложные</option></select><label for="sensitivity">Чувствительность мыши</label><input id="sensitivity" type="range" min=".25" max="2.5" step=".05" value="${save.settings.sensitivity}"><button id="saveSettings" class="primary">СОХРАНИТЬ</button><button id="closeSettings" class="text-btn">← Назад</button>`);$('quality').value=save.settings.quality;$('difficulty').value=save.settings.difficulty;$('volume').oninput=()=>{initAudio();if(master)master.gain.value=+$('volume').value;};const back=()=>{if(master)master.gain.value=save.settings.volume;if(inBattle){paused=false;pause();}else $('modal').hidden=true;};$('closeSettings').onclick=back;$('saveSettings').onclick=()=>{save.settings={volume:+$('volume').value,quality:$('quality').value,difficulty:$('difficulty').value,sensitivity:+$('sensitivity').value};persist();applyQuality();back();};}
function applyQuality(){renderer.shadowMap.enabled=save.settings.quality==='high';renderer.setPixelRatio(Math.min(devicePixelRatio,save.settings.quality==='high'?2:1));if(scene)scene.traverse(o=>{if(o.material)o.material.needsUpdate=true;});}
function details(){const s=D.stats(chosen(),save.modules[save.selected]);showModal(`<div class="eyebrow">ПАСПОРТ МАШИНЫ · ${s.nation.toUpperCase()}</div><h2>${s.name}</h2><table>${[['Класс',s.cls],['Уровень',s.level+'/5'],['Прочность',s.hp+' HP'],['Урон',s.damage],['Перезарядка',s.reload+' с'],['Скорость',Math.round(s.speed*3.6)+' км/ч'],['Поворот корпуса',(s.turn*180/Math.PI).toFixed(0)+' °/с'],['Поворот башни',(s.turret*180/Math.PI).toFixed(0)+' °/с'],['Снижение урона бронёй',s.armor+'%'],['Дальность обзора',s.view+' м'],['Оптическое увеличение',s.zoom.toFixed(2)+'×'],['Точность',Math.round((1-s.spread)*1000)/10+'%'],['Разброс',s.spread.toFixed(3)+' рад'],['Время сведения',s.aim.toFixed(2)+' с'],['Прочность ходовой',s.tracks+' (паспорт)'],['Маскировка',Math.round(s.camo*100)+'%']].map(([k,v])=>`<tr><td>${k}</td><td>${v}</td></tr>`).join('')}</table><p class="help-note">Оптика включается удержанием Shift. Увеличение зависит от класса, нации и уровня модернизации.</p><button id="closeDetails" class="secondary">← Назад в ангар</button>`);$('closeDetails').onclick=()=>$('modal').hidden=true;}
function help(){showModal('<div class="eyebrow">КУРС МОЛОДОГО КОМАНДИРА</div><h2>Займите свой рубеж</h2><p>В одиночном режиме вы и два союзных бота сражаетесь против трёх противников. В локальной сети — честный бой 1 × 1.</p><div class="tutorial-keys"><span><kbd>W / S</kbd> вперёд / назад</span><span><kbd>A / D</kbd> поворот корпуса</span><span><kbd>Мышь</kbd> башня и камера</span><span><kbd>ЛКМ</kbd> выстрел</span><span><kbd>Shift</kbd> оптика танка</span><span><kbd>Пробел</kbd> выстрел</span><span><kbd>Tab</kbd> состав команд</span><span><kbd>Esc</kbd> пауза</span></div><p>Удерживайте Shift для оптического прицела. Его увеличение зависит от характеристик выбранной машины и растёт с модернизацией.</p><p>Для боя через Radmin хост запускает PLAY.cmd, создаёт лобби и передаёт другу адрес сервера и пятизначный код.</p><button id="closeHelp" class="primary">ПОНЯТНО →</button>');$('closeHelp').onclick=()=>{$('modal').hidden=true;};}
function scoreboard(){if(state!=='battle'||paused)return;$('scoreboard').hidden=false;const order=player.team===0?[0,1]:[1,0];$('teamList').innerHTML=order.map((team,index)=>`<p class="${index===0?'ally':'enemy'}">${index===0?'ВАША КОМАНДА':'ПРОТИВНИК'}</p>`+tanks.filter(t=>t.team===team).map(t=>`<div class="team-row ${t.alive?'':'dead'}"><span>${t.name} · ${t.spec.name}${t.brain?' · '+botRoles[t.brain.role]:''}</span><b>${t.alive?Math.ceil(t.hp)+' HP':'Уничтожен'}</b></div>`).join('')).join('');}
function bindMobileControls(){
 const buttons=document.querySelectorAll?document.querySelectorAll('[data-touch-key]'):[];buttons.forEach(button=>{const code=button.dataset.touchKey;const press=e=>{e.preventDefault();initAudio();keys[code]=true;button.classList.add('pressed');};const release=e=>{e.preventDefault();keys[code]=false;button.classList.remove('pressed');};button.addEventListener('pointerdown',press,{passive:false});button.addEventListener('pointerup',release,{passive:false});button.addEventListener('pointercancel',release,{passive:false});button.addEventListener('pointerleave',release,{passive:false});});
 const aim=$('touchAim'),fireButton=$('touchFire');if(aim){const on=e=>{e.preventDefault();keys.ShiftLeft=true;aim.classList.add('pressed');};const off=e=>{e.preventDefault();keys.ShiftLeft=false;aim.classList.remove('pressed');};aim.addEventListener('pointerdown',on,{passive:false});aim.addEventListener('pointerup',off,{passive:false});aim.addEventListener('pointercancel',off,{passive:false});}if(fireButton){const on=e=>{e.preventDefault();initAudio();mouseDown=true;fireButton.classList.add('pressed');};const off=e=>{e.preventDefault();mouseDown=false;fireButton.classList.remove('pressed');};fireButton.addEventListener('pointerdown',on,{passive:false});fireButton.addEventListener('pointerup',off,{passive:false});fireButton.addEventListener('pointercancel',off,{passive:false});}
 const canvas=$('world');let look=null;canvas.addEventListener('touchstart',e=>{if(state!=='battle'||e.target.closest('#mobileControls'))return;const t=e.changedTouches[0];look={id:t.identifier,x:t.clientX,y:t.clientY};},{passive:true});canvas.addEventListener('touchmove',e=>{if(!look)return;const t=[...e.changedTouches].find(v=>v.identifier===look.id);if(!t)return;e.preventDefault();viewYaw-=(t.clientX-look.x)*.006*save.settings.sensitivity;viewPitch=THREE.MathUtils.clamp(viewPitch-(t.clientY-look.y)*.003*save.settings.sensitivity,-.28,.65);look.x=t.clientX;look.y=t.clientY;},{passive:false});canvas.addEventListener('touchend',e=>{if([...e.changedTouches].some(t=>t.identifier===look?.id))look=null;},{passive:true});
}
bindMobileControls();
function bind(){
 $('hangarTab').onclick=()=>showGarageSection('hangar');$('researchTab').onclick=()=>{researchNation=chosen().n;showGarageSection('research');};$('tasksTab').onclick=()=>{showModal('<div class="eyebrow">БОЕВЫЕ ЗАДАЧИ</div><h2>Приказы командования</h2><div class="row"><span>Провести один бой</span><b>+300 ◉</b></div><div class="row"><span>Обнаружить противника</span><b>+25 ◉</b></div><div class="row"><span>Одержать победу</span><b>+200 ◉</b></div><button id="closeTasks" class="secondary">ЗАКРЫТЬ</button>');$('closeTasks').onclick=()=>{$('modal').hidden=true;};};$('researchClose').onclick=()=>showGarageSection('hangar');
 for(const key of Object.keys(D.moduleNames))$('module-'+key).onclick=()=>{selectedModule=key;renderGarage();sound('ui');};
 $('armorBtn').onclick=()=>{armorView=!armorView;Remaster.armorMask(preview,armorView,D.stats(chosen(),save.modules[save.selected]));$('armorLegend').hidden=!armorView;renderGarage();};$('unlockBtn').onclick=()=>{if(D.unlock(save,save.selected)){persist();renderGarage();toast('Танк исследован и куплен');}};
 $('fullscreenBtn').onclick=()=>{if(document.fullscreenElement)document.exitFullscreen?.();else document.documentElement.requestFullscreen?.()?.catch?.(()=>toast('Откройте игру в отдельном окне браузера.'));};
 $('battleBtn').onclick=()=>{$('modeSelect').value==='lan'?showLan():startBattle();};$('upgradeBtn').onclick=()=>{if(D.upgradeModule(save,save.selected,selectedModule)){persist();renderGarage();sound('ui');toast('Модуль «'+D.moduleNames[selectedModule]+'»: уровень '+roman[save.modules[save.selected][selectedModule]-1]);}};$('settingsBtn').onclick=settings;$('helpBtn').onclick=help;$('detailsBtn').onclick=details;$('pauseBtn').onclick=pause;$('shelfPrev').onclick=()=>$('tankCards').scrollBy({left:-240,behavior:'smooth'});$('shelfNext').onclick=()=>$('tankCards').scrollBy({left:240,behavior:'smooth'});$('mapSelect').onchange=()=>{save.map=$('mapSelect').value;persist();updateMapCard();};$('modeSelect').onchange=updateModeCard;
 window.addEventListener('keydown',e=>{if(['Space','Tab','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.code)&&state==='battle')e.preventDefault();keys[e.code]=true;if(e.code==='Escape'){if(state==='battle'){if(paused)resume();else pause();}else if(state==='garage')$('modal').hidden=true;}if(e.code==='Tab')scoreboard();});window.addEventListener('keyup',e=>{keys[e.code]=false;if(e.code==='Tab')$('scoreboard').hidden=true;});
 const canvas=$('world');canvas.addEventListener('contextmenu',e=>e.preventDefault());canvas.addEventListener('mousedown',e=>{initAudio();if(state==='garage') {drag=true;dragX=e.clientX;return;}if(state!=='battle'||paused||!player.alive)return;if(e.button===0){mouseDown=true;if(!document.pointerLockElement)canvas.requestPointerLock?.()?.catch?.(()=>{});}});window.addEventListener('mouseup',()=>{mouseDown=false;drag=false;});
 window.addEventListener('mousemove',e=>{if(state==='garage'&&drag){preview.group.rotation.y+=(e.clientX-dragX)*.008;dragX=e.clientX;}if(state==='battle'&&!paused&&player.alive){if(document.pointerLockElement){viewYaw-=e.movementX*.0025*save.settings.sensitivity;viewPitch=THREE.MathUtils.clamp(viewPitch-e.movementY*.0015*save.settings.sensitivity,-.28,.65);}else{const nx=e.clientX/innerWidth-.5;keys.edgeTurn=Math.abs(nx)>.13?-nx*1.6:0;viewPitch=THREE.MathUtils.clamp((.5-e.clientY/innerHeight)*.6,-.28,.4);}}});
 document.addEventListener('pointerlockchange',()=>{if(!document.pointerLockElement&&state==='battle'&&!paused&&player?.alive)pause();});document.addEventListener('visibilitychange',()=>{if(document.hidden){pause();audio?.suspend();}});window.addEventListener('blur',()=>{Object.keys(keys).forEach(k=>keys[k]=false);pause();audio?.suspend();});window.addEventListener('resize',()=>{renderer.setSize(innerWidth,innerHeight);camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();});
}
function animate(now){const dt=Math.min(.045,(now-lastTime)/1000||.016);lastTime=now;if(state==='garage'){/* Keep the reference pose until the player drags the tank. */}else if(state==='battle'&&!paused){if(!document.pointerLockElement)viewYaw+=(keys.edgeTurn||0)*dt;updateBattle(dt,now);}if(state==='battle'&&player){const sun=scene.userData.sun,p=player.group.position;sun.position.set(p.x-65,p.y+105,p.z+55);sun.target.position.copy(p);sun.target.updateMatrixWorld();}const hideOwn=state==='battle'&&aiming&&player?.alive;if(hideOwn)player.group.visible=false;try{Remaster.render(renderer,scene,camera,save.settings.quality==='high');}finally{if(hideOwn)player.group.visible=true;}}
try{renderer=new THREE.WebGLRenderer({canvas:$('world'),antialias:true,powerPreference:'high-performance'});renderer.setSize(innerWidth,innerHeight);renderer.shadowMap.type=THREE.PCFSoftShadowMap;renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.04;camera=new THREE.PerspectiveCamera(45,innerWidth/innerHeight,.15,2400);applyQuality();bind();hangar();renderer.render(scene,camera);$('loading').hidden=true;Platform.markReady();renderer.setAnimationLoop(animate);Platform.init((cloud,started)=>{if(state==='garage'&&save.updated<started&&cloud.updated>save.updated){save=cloud;hangar();toast('Облачный прогресс восстановлен');}},pause);}
catch(error){console.error(error);$('loading').innerHTML='<h1>Не удалось запустить 3D</h1><p>Включите аппаратное ускорение в браузере и обновите драйвер видеокарты.</p><p>'+String(error.message).replace(/[<>]/g,'')+'</p>';}
// Read-only inspection, useful for support and acceptance tests.
window.gameStatus=()=>({state,paused,countdown,armorView,owned:{...save.owned},map:save.map,tank:save.selected,mode:matchMode,network:net?{role:net.role,code:net.code,players:net.players?.length||0}:null,silver:save.silver,levels:{...save.levels},modules:structuredClone(save.modules),elapsed,camera:{fov:camera?.fov,zoom:camera?.zoom,aiming},player:player?{team:player.team,hp:player.hp,x:player.group.position.x,z:player.group.position.z,reload:player.reload,zoom:player.spec.zoom}:null,teams:tanks.map(t=>({team:t.team,hp:t.hp,alive:t.alive,role:t.brain?.role,behavior:t.brain?.mode,x:t.group.position.x,z:t.group.position.z})),drawCalls:renderer?.info.render.calls});
})();
